# Next.js Professional Starter

Next.js Professional Starter is a reusable baseline for modern Next.js applications with TypeScript, consistent development tooling, and product documentation.

---

## Requirements

Before running the project, make sure the following tools are installed:

- Node.js 20+
- pnpm

## Getting Started

This section describes how to install dependencies, run the development server, and build the application for production.

### Install dependencies

Install project dependencies.

```bash
pnpm install
```

### Start development server

Run the local development server.

```bash
pnpm dev
```

The application will be available at:
http://localhost:3000

### Create production build

Build the application for production use.

```bash
pnpm build
```

### Start production server

Run the built production application.

```bash
pnpm start
```

## Available Commands

The repository exposes the following commands:

```bash
- `pnpm dev`
- `pnpm build`
- `pnpm start`
- `pnpm lint`
- `pnpm format`
- `pnpm format:check`
- `pnpm tsc`
- `pnpm check`
```

## Command Reference

### Start development server

Run the local development server.

```bash
pnpm dev
```

### Create production build

Build the application for production use.

```bash
pnpm build
```

### Start production server

Run the built production application.

```bash
pnpm start
```

### Run lint checks

Verify repository code quality with ESLint.

```bash
pnpm lint
```

### Format repository

Apply repository formatting with Prettier.

```bash
pnpm format
```

### Check formatting

Verify formatting without modifying files.

```bash
pnpm format:check
```

### Run type checking

Validate TypeScript types without emitting build output.

```bash
pnpm tsc
```

### Run combined checks

Run the combined repository validation workflow.

```bash
pnpm check
```

## Tech Stack

The project uses the following tools:

- Next.js
- React
- TypeScript
- ESLint
- Prettier
- Husky
- lint-staged
- Commitlint

## Repository Structure

Key repository paths include:

- docs/
- internal/adr/
- scripts/
- src/app/
- src/components/
- src/lib/

Important configuration files include:

- next.config.ts
- tsconfig.json
- eslint.config.mjs
- .prettierrc.js
- package.json

## Documentation

Project documentation is maintained in the following paths:

- docs/site/
- docs/nav.ts

The documentation includes setup instructions, command reference, tooling guidance, project structure notes, CI information, and troubleshooting guidance.

## Notes

This repository is intended to serve as a reusable professional starter rather than a one-off test assignment.
