import styles from './page.module.css';

export default function HomePage() {
  return (
    <main className={styles.container}>
      <div className={styles.content}>
        <span className={styles.productLabel}>Built by Software Forge</span>

        <h1 className={styles.title}>Next.js Professional Starter</h1>

        <p className={styles.description}>
          This project provides a professional baseline for modern Next.js applications.
        </p>
      </div>
    </main>
  );
}
