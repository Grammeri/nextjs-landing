import { execSync } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';

function buildTree(paths) {
  const root = {};

  for (const p of paths) {
    const parts = p.split('/');
    let node = root;

    for (const part of parts) {
      if (!node[part]) node[part] = {};
      node = node[part];
    }
  }

  return root;
}

function renderTree(node, prefix = '') {
  const entries = Object.entries(node).sort(([a], [b]) => a.localeCompare(b));

  let output = '';

  entries.forEach(([name, children], index) => {
    const isLast = index === entries.length - 1;
    const branch = isLast ? '└─ ' : '├─ ';

    output += `${prefix}${branch}${name}\n`;

    const nextPrefix = prefix + (isLast ? '   ' : '│  ');
    output += renderTree(children, nextPrefix);
  });

  return output;
}

try {
  const projectName = path.basename(process.cwd());

  const files = execSync('git ls-files').toString().trim().split('\n').filter(Boolean);

  const tree = buildTree(files);
  const rendered = renderTree(tree);

  const output = `${projectName}/\n${rendered}`;

  fs.mkdirSync('dev', { recursive: true });
  fs.writeFileSync('dev/tree.pretty.txt', output);

  console.log('✅ Tree generated: dev/tree.pretty.txt');
} catch (error) {
  console.error('❌ Failed to generate tree');
  console.error(error);
  process.exit(1);
}
