import fs from 'node:fs/promises';
import path from 'node:path';
import process from 'node:process';

const repoRoot = process.cwd();

const sourceSiteDir = path.join(repoRoot, 'docs', 'site');
const sourceNavFile = path.join(repoRoot, 'docs', 'nav.ts');

const landingRepoPath = process.env.LANDING_REPO_PATH;
const landingDocsSiteDir = path.join(landingRepoPath, 'src', 'content', 'docs-site', 'starter');
const landingNavFile = path.join(
  landingRepoPath,
  'src',
  'content',
  'docs-nav',
  'starter',
  'nav.ts',
);

async function ensureDir(dirPath) {
  await fs.mkdir(dirPath, { recursive: true });
}

async function clearDirectory(dirPath) {
  await ensureDir(dirPath);
  const entries = await fs.readdir(dirPath, { withFileTypes: true });

  await Promise.all(
    entries.map(async (entry) => {
      const fullPath = path.join(dirPath, entry.name);
      await fs.rm(fullPath, { recursive: true, force: true });
    }),
  );
}

async function copyDirectory(sourceDir, targetDir) {
  await ensureDir(targetDir);
  const entries = await fs.readdir(sourceDir, { withFileTypes: true });

  await Promise.all(
    entries.map(async (entry) => {
      const sourcePath = path.join(sourceDir, entry.name);
      const targetPath = path.join(targetDir, entry.name);

      if (entry.isDirectory()) {
        await copyDirectory(sourcePath, targetPath);
        return;
      }

      await fs.copyFile(sourcePath, targetPath);
    }),
  );
}

async function assertPathExists(targetPath, label) {
  try {
    await fs.access(targetPath);
  } catch {
    throw new Error(`${label} not found: ${targetPath}`);
  }
}

async function main() {
  if (!landingRepoPath) {
    throw new Error('LANDING_REPO_PATH is required');
  }

  await assertPathExists(sourceSiteDir, 'Starter docs/site directory');
  await assertPathExists(sourceNavFile, 'Starter docs/nav.ts file');
  await assertPathExists(landingRepoPath, 'Landing repository path');

  await clearDirectory(landingDocsSiteDir);
  await copyDirectory(sourceSiteDir, landingDocsSiteDir);

  await ensureDir(path.dirname(landingNavFile));
  await fs.copyFile(sourceNavFile, landingNavFile);

  console.log('Starter docs synced successfully.');
  console.log(`Source docs: ${sourceSiteDir}`);
  console.log(`Target docs: ${landingDocsSiteDir}`);
  console.log(`Target nav: ${landingNavFile}`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
