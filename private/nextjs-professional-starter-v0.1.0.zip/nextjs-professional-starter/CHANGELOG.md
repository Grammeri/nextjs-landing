# Changelog

All notable changes to this project will be documented in this file.

The format is loosely based on Keep a Changelog:
https://keepachangelog.com/en/1.1.0/

---

## 0.1.0

Initial project setup.

### Added

- Next.js App Router project structure
- TypeScript configuration
- pnpm package manager setup
- ESLint and Prettier configuration
- Husky + commitlint + lint-staged
- CI pipeline with GitHub Actions
- Project documentation structure
- Development utilities and scripts
