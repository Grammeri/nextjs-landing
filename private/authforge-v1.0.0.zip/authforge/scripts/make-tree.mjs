import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'node:child_process';

const projectRoot = process.cwd();
const outputDir = path.join(projectRoot, 'dev');
const outputFile = path.join(outputDir, 'tree.pretty.txt');

function ensureDir(dirPath) {
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
}

function getGitFiles() {
  try {
    const result = execSync('git ls-files', { encoding: 'utf8' });
    return result.split(/\r?\n/).filter(Boolean);
  } catch {
    console.error('Failed to execute git ls-files');
    process.exit(1);
  }
}

function buildTree(files) {
  const tree = {};

  for (const file of files) {
    const parts = file.split('/');
    let current = tree;

    for (const part of parts) {
      current[part] = current[part] || {};
      current = current[part];
    }
  }

  return tree;
}

function walk(node, output, prefix = '') {
  const keys = Object.keys(node).sort((a, b) => a.localeCompare(b));

  keys.forEach((key, index) => {
    const isLast = index === keys.length - 1;
    const connector = isLast ? '└─ ' : '├─ ';
    output.push(prefix + connector + key);

    const nextPrefix = prefix + (isLast ? '   ' : '│  ');
    walk(node[key], output, nextPrefix);
  });
}

function main() {
  ensureDir(outputDir);

  const files = getGitFiles();
  const tree = buildTree(files);

  const output = [];
  output.push('auth-forge/');
  walk(tree, output);

  fs.writeFileSync(outputFile, output.join('\n'), 'utf8');

  console.log(`Tree generated: ${outputFile}`);
}

main();
