# AuthForge

AuthForge is a production-ready authentication foundation for modern SaaS applications.

It provides a complete email-based authentication system with sessions, verification, and
secure defaults, designed to be embedded into your own product rather than used as a
standalone service.

AuthForge is a source-code product — you fully own and control the system.

---

## What You Get

- Email & password authentication
- Email verification and password reset flows
- Access / refresh session model with configurable TTL
- HttpOnly cookies (no JWT in localStorage)
- Strong runtime validation (Zod-based)
- bcrypt password hashing
- Optional breached password detection (HIBP k-anonymity model)
- Demo mode for instant local testing
- Production-ready security defaults
- Clean architectural boundaries
- Clear extension points for UI and behavior

## Internationalization

AuthForge includes a minimal dictionary layer for authentication-related UI.

Internationalization is optional.

- You may keep English-only setup.
- You may extend with additional languages.
- You may remove the dictionary layer entirely.

Authentication business logic remains language-agnostic.

## Prerequisites

Make sure the following tools are installed:

- Node.js 20+
- pnpm
- Docker (Docker Desktop must be running)

AuthForge uses a local PostgreSQL instance running in Docker and Prisma ORM 6.x for database access.

## Getting Started

### Run full setup

Run the following command from the project root.

```bash
pnpm setup
```

This command will:

- install dependencies
- start the required PostgreSQL container via Docker
- generate the Prisma Client
- apply database migrations

AuthForge v1.0.0 is validated against Prisma ORM 6.x and uses the stable direct connection runtime model.

### Start development server

Once setup is complete, start the development server.

```bash
pnpm dev
```

### Open application

The application is available at:

http://localhost:3000

## Environment Configuration

AuthForge uses a centralized environment module with runtime validation.

Configuration is controlled via `.env`:

- Database connection
- Backend demo mode toggle
- Frontend demo UI settings
- Email delivery configuration
- Security settings

See:

`docs/site/environment.md`

AuthForge fails fast if required environment variables are missing.

## Database Requirement in Demo Mode

Demo mode does not disable the database.

Even when:

```env
AUTH_DEMO_MODE=true
```

AuthForge still requires a running PostgreSQL instance.

Demo mode replaces only external side effects (such as email delivery).  
All authentication rules, password hashing, session handling, and database persistence remain fully active.

This ensures identical domain behavior between demo and production environments.

## Email Behavior

AuthForge does not provide hosted email infrastructure.

It includes:

- Demo email provider (console simulation)
- Email abstraction layer
- Example Resend integration

Production email delivery must be configured by the buyer.

See:

`docs/site/integration/email.md`

## Documentation

AuthForge documentation is located in the `docs/` directory.

Start here:

- Getting Started -> `docs/site/getting-started.md`
- Architecture -> `docs/site/architecture.md`
- Demo Mode -> `docs/site/demo-mode.md`
- Environment Variables -> `docs/site/environment.md`
- Security -> `docs/site/security.md`

## Extending AuthForge

- After login behavior -> `docs/site/integration/after-login.md`
- Development commands -> `docs/site/integration/commands.md`
- Email delivery customization -> `docs/site/integration/email.md`
- UI customization -> `docs/site/ui-principles.md`

Authentication logic is isolated inside the domain layer and can be extended
without breaking architectural boundaries.

## Philosophy

AuthForge is built as a foundation, not a framework.

It enforces:

- Strict architectural boundaries
- Minimal public surface
- Server-only secret handling
- No hidden magic
- Developer ownership of the system

Authentication logic is isolated, predictable, and safe to extend, allowing product teams
to focus on business logic without reinventing security-critical flows.
