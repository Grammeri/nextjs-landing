import { PrismaClient } from '@prisma/client';

/**
 * Global Prisma instance.
 *
 * Prevents multiple PrismaClient instances in development
 * due to hot reload (which can exhaust DB connections).
 *
 * In production, a new instance is always created.
 */

const globalForPrisma = globalThis as unknown as {
  prisma?: PrismaClient;
};

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
  });

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = prisma;
}
