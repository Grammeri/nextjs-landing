# Docker Development Setup

This document defines the development-only Docker setup for AuthForge.
The Docker configuration exists solely to provide a predictable local PostgreSQL environment. It is not required for production usage and is not part of the runtime system architecture.

---

## Purpose

The Docker setup provides:

- local PostgreSQL instance
- isolated development database
- zero external dependency during onboarding
- consistent environment across machines

It does not provide:

- production infrastructure
- hosting
- managed database services
- deployment automation

## Architecture Overview

The Docker configuration consists of:

- one PostgreSQL service
- one named volume for data persistence

The application connects to PostgreSQL using the DATABASE_URL defined in the environment configuration.
Docker does not affect Prisma schema design or runtime behavior.

## Running PostgreSQL Locally

### Start PostgreSQL container

AuthForge provides a convenience script for starting the local PostgreSQL container.

```bash
pnpm db:up
```

This command internally runs Docker Compose using the configuration located at:

[infra/docker/docker-compose.yml](infra/docker/docker-compose.yml)

### Stop PostgreSQL container

Stop and remove the running PostgreSQL container.

```bash
pnpm db:down
```

### Manual Docker commands (optional)

Advanced users may run Docker commands directly.

### Start PostgreSQL via Docker Compose

```bash
docker compose --env-file .env -f infra/docker/docker-compose.yml up -d
```

### Stop PostgreSQL via Docker Compose

```bash
docker compose --env-file .env -f infra/docker/docker-compose.yml down
```

### Remove persistent volume

Removes the named Docker volume and deletes all database data.

```bash
docker volume rm postgres_data
```

Removing the volume will reset the database to an empty state.

## Database Connection

The application connects using the DATABASE_URL environment variable.

Example development configuration:

```env
DATABASE_URL=postgresql://postgres:postgres@localhost:5433/authforge_demo
```

Docker container names do not affect Prisma behavior. Database access is determined solely by the connection string (`DATABASE_URL`).

## Production Usage

In production:

- Docker is optional
- PostgreSQL may be hosted externally
- Only DATABASE_URL must be updated

No changes to Prisma schema or application logic are required.

## Final Notes

The Docker setup is a development convenience layer.
It may be removed without affecting the application architecture, provided that a valid PostgreSQL instance is configured through DATABASE_URL.
