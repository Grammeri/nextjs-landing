import { NextRequest, NextResponse } from 'next/server';
import { handleI18n } from '@/shared/i18n/middleware';

/**
 * Edge middleware.
 *
 * IMPORTANT:
 * - Must not access database or Prisma
 * - Handles locale detection and redirection
 */
export function proxy(req: NextRequest) {
  const i18nResponse = handleI18n(req);

  const response = i18nResponse ?? NextResponse.next();

  // ===== Global Security Headers (HTML only) =====
  response.headers.set('X-Content-Type-Options', 'nosniff');
  response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  response.headers.set('X-Frame-Options', 'DENY');
  response.headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');

  return response;
}

/**
 * IMPORTANT:
 * Middleware must not run for API routes.
 * All database logic belongs to Node.js route handlers.
 */
export const config = {
  matcher: [
    /*
     * Exclude:
     * - API routes
     * - Next.js internals
     * - Static assets
     */
    '/((?!api|_next/static|_next/image|favicon.ico).*)',
  ],
};
