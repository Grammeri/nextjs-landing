export const en = {
  auth: {
    login: {
      title: 'Sign in',
      submit: 'Sign in',
      successMessage: 'Signed in successfully',
      emailLabel: 'Email',
      passwordLabel: 'Password',
      forgotLink: 'Forgot password?',
      noAccount: "Don't have an account?",
      registerLink: 'Create account',
    },

    register: {
      title: 'Create account',
      submit: 'Create account',
      emailLabel: 'Email',
      passwordLabel: 'Password',
      confirmPasswordLabel: 'Confirm password',
      haveAccount: 'Already have an account?',
      loginLink: 'Sign in',
      verificationNotice: 'Please verify your email to continue.',
      verificationEmailSent: 'We sent you a verification email. Check your inbox.',
      verifyDemoButton: 'Verify email (demo)',
      copyDemoLink: 'Copy verification link',
      copyDemoButton: 'Copy verification link',
      demoLinkCopied: 'Verification link copied',
      demoLinkCopyFailed: 'Unable to copy link. Please copy it manually.',
    },

    forgot: {
      title: 'Forgot password',
      emailPlaceholder: 'name@example.com',
      description: 'Enter your email and we will send you a reset link.',
      submit: 'Send reset link',
      emailLabel: 'Email',
      backToLogin: 'Back to sign in',
      successMessage: 'If an account with this email exists, a password reset link has been sent.',
      demoLabel: 'Reset password link (demo)',
      demoButton: 'Reset password (demo)',
    },

    reset: {
      title: 'Reset password',
      description: 'Enter your new password below',
      submit: 'Reset password',
      passwordLabel: 'New password',
      confirmPasswordLabel: 'Confirm password',
      backToLogin: 'Back to sign in',

      showPassword: 'Show',
      hidePassword: 'Hide',

      invalidLinkTitle: 'Invalid reset link',
      invalidLinkMessage: 'This password reset link is invalid or has expired.',
      successMessage: 'Password updated successfully',
    },

    verifyEmail: {
      successTitle: 'Email verified',
      successText: 'Your email has been successfully verified. You can now sign in.',
      ctaToLogin: 'Go to sign in',
      toastSuccess: 'Email successfully verified',

      errorTitle: 'Verification failed',
      errorText: 'This verification link is invalid or has expired. Please request a new one.',
      toastError: 'Email verification failed',
    },

    errors: {
      generic: 'Something went wrong. Please try again.',
      network: 'Network error. Please try again.',
      invalidCredentials: 'Invalid email or password.',
      emailNotVerified: 'Please verify your email before signing in.',
      emailAlreadyExists: 'An account with this email already exists.',
      passwordPwned: 'This password has appeared in a data breach. Please choose a different one.',
      tooManyAttempts: 'Too many attempts. Please try again later.',

      emailRequired: 'Email is required.',
      emailInvalid: 'Invalid email address.',
      emailAscii: 'Email must use Latin characters only.',

      passwordRequired: 'Password is required.',
      passwordMinLength: 'Password must be at least 12 characters.',
      passwordMaxLength: 'Password must be less than 64 characters.',
      passwordLetter: 'Password must contain at least one letter.',
      passwordUppercase: 'Password must contain at least one uppercase letter.',
      passwordLowercase: 'Password must contain at least one lowercase letter.',
      passwordNumber: 'Password must contain at least one number.',
      passwordNoSpaces: 'Password must not contain spaces.',

      confirmPasswordRequired: 'Please confirm your password.',
      passwordsDoNotMatch: 'Passwords do not match.',
    },

    common: {
      emailLabel: 'Email',
      emailPlaceholder: 'name@example.com',
      showPassword: 'Show',
      hidePassword: 'Hide',
    },
  },
} as const;

export type DictionaryEn = typeof en;
