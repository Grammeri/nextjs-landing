type DeepStringify<T> = {
  readonly [K in keyof T]: T[K] extends string
    ? string
    : T[K] extends object
      ? DeepStringify<T[K]>
      : T[K];
};

export type Dictionary = DeepStringify<typeof import('./dict/en').en>;

export async function getDictionary(): Promise<Dictionary> {
  const { en } = await import('./dict/en');
  return en as Dictionary;
}
