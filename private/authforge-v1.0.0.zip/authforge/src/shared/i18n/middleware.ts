import { NextRequest, NextResponse } from 'next/server';
import { defaultLocale, isLocale } from './config';

/**
 * Handles locale detection and redirection in Edge middleware.
 *
 * Responsibilities:
 * - Detect if pathname already contains a supported locale
 * - Ignore API, Next.js internals, and static assets
 * - Redirect non-localized paths to defaultLocale-prefixed routes
 *
 * Contract:
 * - Returns null if no redirect is required
 * - Returns NextResponse.redirect if locale prefix must be added
 *
 * IMPORTANT:
 * - Must remain pure (no database or side-effects)
 * - Runs in Edge Runtime
 */
export function handleI18n(req: NextRequest): NextResponse | null {
  const { pathname } = req.nextUrl;

  // Skip non-page routes
  if (pathname.startsWith('/api') || pathname.startsWith('/_next') || pathname === '/favicon.ico') {
    return null;
  }

  const segments = pathname.split('/');
  const pathnameLocale = segments[1];

  // If no locale segment (e.g. "/") → redirect to default locale root
  if (!pathnameLocale) {
    const newUrl = new URL(`/${defaultLocale}`, req.url);
    return NextResponse.redirect(newUrl);
  }

  // If valid supported locale → allow request
  if (isLocale(pathnameLocale)) {
    return null;
  }

  // Otherwise redirect to default locale-prefixed route
  const newUrl = new URL(`/${defaultLocale}${pathname}`, req.url);
  return NextResponse.redirect(newUrl);
}
