import type { ReactNode } from 'react';
import styles from './FormFooter.module.css';

type FormFooterProps = {
  children: ReactNode;
};

export function FormFooter({ children }: FormFooterProps) {
  return <div className={styles.footer}>{children}</div>;
}
