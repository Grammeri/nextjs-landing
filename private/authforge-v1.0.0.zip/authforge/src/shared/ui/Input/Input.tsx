'use client';

import { forwardRef, useState } from 'react';
import styles from './Input.module.css';

type InputProps = {
  label?: string;
  error?: string | undefined;
  showPasswordToggle?: boolean;
  showPasswordText?: string;
  hidePasswordText?: string;
} & React.InputHTMLAttributes<HTMLInputElement>;

export const Input = forwardRef<HTMLInputElement, InputProps>(
  (
    {
      label,
      error,
      showPasswordToggle,
      showPasswordText = 'Show',
      hidePasswordText = 'Hide',
      type,
      ...props
    },
    ref,
  ) => {
    const [isPasswordVisible, setIsPasswordVisible] = useState(false);

    const isPasswordType = type === 'password';
    const shouldShowToggle = isPasswordType && showPasswordToggle;
    const inputType = shouldShowToggle && isPasswordVisible ? 'text' : type;

    return (
      <div className={styles.wrapper}>
        {label && <label className={styles.label}>{label}</label>}

        <div className={styles.inputWrapper}>
          <input
            ref={ref}
            {...props}
            type={inputType}
            className={`${styles.input} ${error ? styles.inputError : ''} ${
              shouldShowToggle ? styles.withToggle : ''
            }`}
          />

          {shouldShowToggle && (
            <button
              type="button"
              onClick={() => setIsPasswordVisible(!isPasswordVisible)}
              className={styles.toggle}
            >
              {isPasswordVisible ? hidePasswordText : showPasswordText}
            </button>
          )}
        </div>

        {error && <div className={styles.error}>{error}</div>}
      </div>
    );
  },
);

Input.displayName = 'Input';
