'use client';

import styles from './Spinner.module.css';

type SpinnerProps = {
  size?: 'sm' | 'md' | 'lg';
};

export function Spinner({ size = 'md' }: SpinnerProps) {
  return (
    <span
      className={`${styles.spinner} ${styles[size]}`}
      role="status"
      aria-live="polite"
      aria-label="Loading"
    />
  );
}
