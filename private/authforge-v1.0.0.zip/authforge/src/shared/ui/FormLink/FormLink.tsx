import Link from 'next/link';

import styles from './FormLink.module.css';

type FormLinkProps = {
  href: string;
  children: React.ReactNode;
  className?: string;
};

export function FormLink({ href, children, className }: FormLinkProps) {
  const cn = className ? `${styles.link} ${className}` : styles.link;

  return (
    <Link href={href} className={cn}>
      {children}
    </Link>
  );
}
