'use client';

import { Spinner } from '@/shared/ui/Spinner/Spinner';
import styles from './Button.module.css';

type ButtonProps = {
  loading?: boolean;
} & React.ButtonHTMLAttributes<HTMLButtonElement>;

export function Button({ loading, children, className = '', ...props }: ButtonProps) {
  const isDisabled = loading || props.disabled;

  return (
    <button {...props} disabled={isDisabled} className={`${styles.button} ${className}`}>
      {loading ? <Spinner size="sm" /> : children}
    </button>
  );
}
