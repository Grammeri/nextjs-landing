'use client';

import styles from './FormError.module.css';

type Props = {
  children: string;
};

export function FormError({ children }: Props) {
  return <div className={styles.error}>{children}</div>;
}
