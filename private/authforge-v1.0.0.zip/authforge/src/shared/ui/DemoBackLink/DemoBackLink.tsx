'use client';

import { isDemoUi, demoReturnUrl } from '@/shared/config/demo';
import styles from './DemoBackLink.module.css';

export function DemoBackLink() {
  if (!isDemoUi || !demoReturnUrl) {
    return null;
  }

  return (
    <a href={demoReturnUrl} className={styles.link}>
      ← Back to AuthForge
    </a>
  );
}
