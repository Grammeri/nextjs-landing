export interface RateLimitConfig {
  limit: number;
  windowMs: number;
}

export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  resetAt: number;
}

type Entry = {
  count: number;
  expiresAt: number;
};

const store = new Map<string, Entry>();

export function rateLimit(key: string, config: RateLimitConfig): RateLimitResult {
  const now = Date.now();
  const existing = store.get(key);

  if (!existing || existing.expiresAt <= now) {
    const entry: Entry = {
      count: 1,
      expiresAt: now + config.windowMs,
    };

    store.set(key, entry);

    return {
      allowed: true,
      remaining: config.limit - 1,
      resetAt: entry.expiresAt,
    };
  }

  if (existing.count >= config.limit) {
    return {
      allowed: false,
      remaining: 0,
      resetAt: existing.expiresAt,
    };
  }

  existing.count += 1;

  return {
    allowed: true,
    remaining: config.limit - existing.count,
    resetAt: existing.expiresAt,
  };
}
