import 'server-only';

import { z } from 'zod';

const schema = z.object({
  AUTH_DEMO_MODE: z.enum(['true', 'false']).default('false'),

  APP_URL: z.string().url('APP_URL must be a valid URL'),

  AUTH_TOKEN_PEPPER: z.string().min(32, 'AUTH_TOKEN_PEPPER must be at least 32 characters long'),

  RESEND_API_KEY: z.string().optional(),
  EMAIL_FROM: z.string().optional(),
});

const parsed = schema.parse(process.env);

if (parsed.AUTH_DEMO_MODE === 'false') {
  if (!parsed.RESEND_API_KEY) {
    throw new Error('RESEND_API_KEY is required in production mode');
  }

  if (!parsed.EMAIL_FROM) {
    throw new Error('EMAIL_FROM is required in production mode');
  }
}

export const env = {
  AUTH_DEMO_MODE: parsed.AUTH_DEMO_MODE === 'true',

  APP_URL: parsed.APP_URL,

  AUTH_TOKEN_PEPPER: parsed.AUTH_TOKEN_PEPPER,

  RESEND_API_KEY: parsed.RESEND_API_KEY ?? '',
  EMAIL_FROM: parsed.EMAIL_FROM ?? '',
} as const;

export {};
