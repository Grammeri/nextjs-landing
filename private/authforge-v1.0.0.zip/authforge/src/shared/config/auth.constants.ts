/* ==========================================
   AUTH CONFIGURATION — COOKIE
========================================== */

export const SESSION_COOKIE_NAME =
  process.env.NODE_ENV === 'production' ? '__Secure-sessionId' : 'sessionId';

/* ==========================================
   AUTH CONFIGURATION — SESSION
========================================== */

export const ACCESS_SESSION_TTL_MINUTES = 15;
export const REFRESH_SESSION_TTL_DAYS = 30;

/* ==========================================
   AUTH CONFIGURATION — PASSWORD
========================================== */

export const PASSWORD_SALT_ROUNDS = 12;

/* ==========================================
   AUTH CONFIGURATION — PASSWORD POLICY
========================================== */

export const PASSWORD_MIN_LENGTH = 12;
export const PASSWORD_MAX_LENGTH = 64;

/* ==========================================
   AUTH CONFIGURATION — TOKENS
========================================== */

export const AUTH_TOKEN_BYTES = 32;

export const AUTH_TOKEN_TTL = {
  EMAIL_VERIFICATION_MS: 24 * 60 * 60 * 1000, // 24h
  PASSWORD_RESET_MS: 60 * 60 * 1000, // 1h
} as const;

/* ==========================================
   AUTH CONFIGURATION — RATE LIMIT
========================================== */

export const AUTH_RATE_LIMIT_CONFIG = {
  limit: 5,
  windowMs: 15 * 60 * 1000,
} as const;
