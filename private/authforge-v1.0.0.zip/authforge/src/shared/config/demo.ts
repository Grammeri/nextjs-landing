// ============================================================
// Backend demo (logic)
// ============================================================

const DEMO_MODE = process.env.AUTH_DEMO_MODE === 'true';

export function isDemoMode(): boolean {
  return DEMO_MODE;
}

// ============================================================
// Frontend demo (UI)
// ============================================================

export const isDemoUi = process.env.NEXT_PUBLIC_DEMO_MODE === 'true';

export const demoReturnUrl = process.env.NEXT_PUBLIC_DEMO_RETURN_URL || null;
