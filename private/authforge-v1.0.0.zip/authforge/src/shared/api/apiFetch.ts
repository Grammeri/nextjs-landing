export class ApiError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly status: number,
    public readonly errors?: unknown,
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

export async function apiFetch<T>(input: RequestInfo, init?: RequestInit): Promise<T> {
  const res = await fetch(input, {
    credentials: 'include',
    headers: {
      'Content-Type': 'application/json',
      ...(init?.headers ?? {}),
    },
    ...init,
  });

  const hasBody = res.headers.get('content-length') !== '0';
  const data = hasBody ? await res.json().catch(() => null) : null;

  if (!res.ok) {
    const code =
      data && typeof data === 'object' && 'code' in data
        ? String((data as { code?: unknown }).code)
        : data && typeof data === 'object' && 'message' in data
          ? String((data as { message?: unknown }).message)
          : 'UNKNOWN_ERROR';

    const message =
      data && typeof data === 'object' && 'message' in data
        ? String((data as { message?: unknown }).message)
        : code;

    const errors =
      data && typeof data === 'object' && 'errors' in data
        ? (data as { errors?: unknown }).errors
        : undefined;

    throw new ApiError(code, message, res.status, errors);
  }

  return data as T;
}
