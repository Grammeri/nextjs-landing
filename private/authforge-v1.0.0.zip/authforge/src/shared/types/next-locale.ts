export type LocaleParams = Promise<{ locale: string }>;

export interface LocaleLayoutProps {
  children: React.ReactNode;
  params: LocaleParams;
}

export interface LocalePageProps {
  params: LocaleParams;
}
