import { readFile } from 'fs/promises';
import path from 'path';
import { notFound } from 'next/navigation';
import { remark } from 'remark';
import remarkGfm from 'remark-gfm';
import remarkHtml from 'remark-html';

/**
 * Allowed documentation slugs.
 *
 * Acts as a type-safe whitelist for /docs/[slug] routes.
 * Prevents arbitrary file access.
 */
export type DocSlug = 'env' | 'getting-started' | 'demo-mode' | 'architecture';

async function renderMarkdown(markdown: string): Promise<string> {
  const result = await remark().use(remarkGfm).use(remarkHtml).process(markdown);

  return result.toString();
}

/**
 * Injects <colgroup> into tables that do not define one.
 *
 * Required for consistent column sizing in documentation tables.
 * This avoids layout shifts across markdown files.
 */
function addDocTableColgroup(html: string): string {
  return html.replace(
    /<table(?![^>]*<colgroup)[^>]*>/g,
    (match) =>
      `${match}<colgroup>
        <col style="width: var(--docs-col-key)" />
        <col style="width: var(--docs-col-required)" />
        <col />
      </colgroup>`,
  );
}

export async function getDocHtml(slug: string): Promise<string> {
  // Sanitize slug to prevent path traversal (../ attacks)

  const safeSlug = slug.replace(/\\/g, '/').replace(/\.\./g, '').replace(/^\/+/, '');

  const docPath = path.join(
    process.cwd(),
    'content',
    'authforge',
    'docs',
    'site',
    `${safeSlug}.md`,
  );

  try {
    const markdown = await readFile(docPath, 'utf8');
    return addDocTableColgroup(await renderMarkdown(markdown));
  } catch {
    notFound();
  }
}
