import { notFound } from 'next/navigation';
import { getDocHtml, type DocSlug } from '../_lib/docs';

export const runtime = 'nodejs';

const DOC_SLUGS: DocSlug[] = ['env', 'getting-started', 'demo-mode', 'architecture'];

export default async function DocsPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;

  if (!DOC_SLUGS.includes(slug as DocSlug)) {
    notFound();
  }

  const html = await getDocHtml(slug as DocSlug);

  return <div className="docs" dangerouslySetInnerHTML={{ __html: html }} />;
}
