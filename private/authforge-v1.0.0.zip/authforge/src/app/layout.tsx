﻿import type { Metadata } from 'next';
import { inter } from '@/shared/config/fonts';
import { Providers } from './providers';
import { Toaster } from 'sonner';
import './globals.css';

export const metadata: Metadata = {
  title: 'AuthForge',
  description: 'Production-ready authentication boilerplate for modern SaaS applications.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={inter.variable}>
        <Providers>
          {children} <Toaster position="top-left" richColors closeButton />
        </Providers>
      </body>
    </html>
  );
}
