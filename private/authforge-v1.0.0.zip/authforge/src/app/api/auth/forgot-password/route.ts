import { z } from 'zod';

import { requestPasswordReset, makeForgotPasswordSchema } from '@/features/auth/server';
import { getDictionary } from '@/shared/i18n/getDictionary';
import { rateLimit } from '@/shared/security/rate-limit';
import { AUTH_RATE_LIMIT_CONFIG } from '@/shared/config/auth.constants';

export const runtime = 'nodejs';

const GENERIC_SUCCESS_MESSAGE =
  'If an account with that email exists, a password reset link has been sent.';

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const dict = await getDictionary();
    const forgotPasswordSchema = makeForgotPasswordSchema(dict.auth.errors);

    const input = forgotPasswordSchema.parse(body);

    const ip = req.headers.get('x-forwarded-for') ?? req.headers.get('x-real-ip') ?? 'unknown';

    const key = `forgot:${ip}:${input.email}`;

    const limit = rateLimit(key, AUTH_RATE_LIMIT_CONFIG);

    if (!limit.allowed) {
      return Response.json(
        { code: 'TOO_MANY_REQUESTS', message: 'Too many attempts' },
        { status: 429 },
      );
    }

    const result = await requestPasswordReset(input.email);

    if (result && typeof result === 'object' && 'demoResetPasswordUrl' in result) {
      return Response.json(
        {
          message: GENERIC_SUCCESS_MESSAGE,
          demoResetPasswordUrl: result.demoResetPasswordUrl,
        },
        { status: 200 },
      );
    }

    return Response.json({ message: GENERIC_SUCCESS_MESSAGE }, { status: 200 });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return Response.json({ message: 'Invalid input', errors: error.issues }, { status: 400 });
    }

    return Response.json({ message: 'Something went wrong' }, { status: 500 });
  }
}
