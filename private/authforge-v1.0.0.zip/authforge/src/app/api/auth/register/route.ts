import { NextResponse } from 'next/server';
import { z } from 'zod';

import { makeRegisterSchema, registerUser, isPasswordPwned } from '@/features/auth/server';
import { getDictionary } from '@/shared/i18n/getDictionary';
import { rateLimit } from '@/shared/security/rate-limit';
import { AUTH_RATE_LIMIT_CONFIG } from '@/shared/config/auth.constants';

export const runtime = 'nodejs';

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);

  if (!body || typeof body !== 'object') {
    return NextResponse.json({ message: 'INVALID_JSON_PAYLOAD' }, { status: 400 });
  }

  const dict = await getDictionary();
  const registerSchema = makeRegisterSchema(dict.auth.errors);

  const parsed = registerSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      {
        message: 'VALIDATION_ERROR',
        errors: parsed.error.issues,
      },
      { status: 400 },
    );
  }

  try {
    const ip = req.headers.get('x-forwarded-for') ?? req.headers.get('x-real-ip') ?? 'unknown';

    const key = `register:${ip}:${parsed.data.email}`;

    const limit = rateLimit(key, AUTH_RATE_LIMIT_CONFIG);

    if (!limit.allowed) {
      return NextResponse.json(
        { code: 'TOO_MANY_REQUESTS', message: 'Too many attempts' },
        { status: 429 },
      );
    }

    const isPwned = await isPasswordPwned(parsed.data.password);

    if (isPwned) {
      return NextResponse.json({ message: 'PASSWORD_PWNED' }, { status: 400 });
    }

    const result = await registerUser(parsed.data);

    return NextResponse.json(result, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        {
          message: 'VALIDATION_ERROR',
          errors: error.issues,
        },
        { status: 400 },
      );
    }

    if (error instanceof Error && error.message === 'EMAIL_ALREADY_EXISTS') {
      return NextResponse.json({ message: 'EMAIL_ALREADY_EXISTS' }, { status: 409 });
    }

    return NextResponse.json({ message: 'UNKNOWN_ERROR' }, { status: 500 });
  }
}
