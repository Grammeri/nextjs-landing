import { NextResponse } from 'next/server';

import {
  AUTH_ERROR_CODES,
  isPasswordPwned,
  makeRegisterSchema,
  registerUser,
} from '@/features/auth/server';
import { AUTH_RATE_LIMIT_CONFIG } from '@/shared/config/auth.constants';
import { getDictionary } from '@/shared/i18n/getDictionary';
import { rateLimit } from '@/shared/security/rate-limit';

export const runtime = 'nodejs';

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);

  if (!body || typeof body !== 'object') {
    return NextResponse.json(
      {
        code: AUTH_ERROR_CODES.INVALID_JSON_PAYLOAD,
      },
      { status: 400 },
    );
  }

  const dict = await getDictionary();
  const registerSchema = makeRegisterSchema(dict.auth.errors);

  const parsed = registerSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      {
        code: AUTH_ERROR_CODES.VALIDATION_ERROR,
        errors: parsed.error.issues,
      },
      { status: 400 },
    );
  }

  try {
    const ip =
      req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
      req.headers.get('x-real-ip') ||
      'unknown';

    const key = `register:${ip}:${parsed.data.email}`;

    const limit = rateLimit(key, AUTH_RATE_LIMIT_CONFIG);

    if (!limit.allowed) {
      return NextResponse.json(
        {
          code: AUTH_ERROR_CODES.TOO_MANY_REQUESTS,
        },
        { status: 429 },
      );
    }

    const isPwned = await isPasswordPwned(parsed.data.password);

    if (isPwned) {
      return NextResponse.json(
        {
          code: AUTH_ERROR_CODES.PASSWORD_PWNED,
        },
        { status: 400 },
      );
    }

    const result = await registerUser(parsed.data);

    if (result && typeof result === 'object' && 'demoVerificationUrl' in result) {
      return NextResponse.json(
        {
          success: true,
          demoVerificationUrl: result.demoVerificationUrl,
        },
        { status: 201 },
      );
    }

    return NextResponse.json({ success: true }, { status: 201 });
  } catch (error) {
    if (error instanceof Error && error.message === AUTH_ERROR_CODES.EMAIL_ALREADY_EXISTS) {
      return NextResponse.json(
        {
          code: AUTH_ERROR_CODES.EMAIL_ALREADY_EXISTS,
        },
        { status: 409 },
      );
    }

    return NextResponse.json(
      {
        code: AUTH_ERROR_CODES.UNKNOWN_ERROR,
      },
      { status: 500 },
    );
  }
}
