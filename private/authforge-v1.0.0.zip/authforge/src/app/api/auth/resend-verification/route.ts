import { NextResponse } from 'next/server';
import { z } from 'zod';

import { resendVerification } from '@/features/auth/server';
import { rateLimit } from '@/shared/security/rate-limit';
import { AUTH_RATE_LIMIT_CONFIG } from '@/shared/config/auth.constants';

export const runtime = 'nodejs';

const emailSchema = z.object({
  email: z.string().email(),
});

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);

  if (!body || typeof body !== 'object') {
    return NextResponse.json({ message: 'INVALID_JSON_PAYLOAD' }, { status: 400 });
  }

  const parsed = emailSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json({ message: 'VALIDATION_ERROR' }, { status: 400 });
  }

  const ip =
    request.headers.get('x-forwarded-for') ?? request.headers.get('x-real-ip') ?? 'unknown';

  const key = `resend:${ip}:${parsed.data.email}`;
  const limit = rateLimit(key, AUTH_RATE_LIMIT_CONFIG);

  if (!limit.allowed) {
    return NextResponse.json({ message: 'TOO_MANY_REQUESTS' }, { status: 429 });
  }

  try {
    await resendVerification(parsed.data.email);
    return NextResponse.json({ success: true }, { status: 200 });
  } catch (error) {
    if (error instanceof Error && error.message === 'EMAIL_ALREADY_VERIFIED') {
      return NextResponse.json({ message: 'EMAIL_ALREADY_VERIFIED' }, { status: 400 });
    }

    return NextResponse.json({ message: 'UNKNOWN_ERROR' }, { status: 500 });
  }
}
