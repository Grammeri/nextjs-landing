import { NextResponse } from 'next/server';
import { z } from 'zod';

import { AUTH_ERROR_CODES, makeEmailWithErrors, resendVerification } from '@/features/auth/server';
import { AUTH_RATE_LIMIT_CONFIG } from '@/shared/config/auth.constants';
import { getDictionary } from '@/shared/i18n/getDictionary';
import { rateLimit } from '@/shared/security/rate-limit';

export const runtime = 'nodejs';

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);

  if (!body || typeof body !== 'object') {
    return NextResponse.json(
      {
        code: AUTH_ERROR_CODES.INVALID_JSON_PAYLOAD,
      },
      { status: 400 },
    );
  }

  const dict = await getDictionary();
  const emailSchema = z.object({
    email: makeEmailWithErrors(dict.auth.errors),
  });

  const parsed = emailSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      {
        code: AUTH_ERROR_CODES.VALIDATION_ERROR,
        errors: parsed.error.issues,
      },
      { status: 400 },
    );
  }

  const ip =
    request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
    request.headers.get('x-real-ip') ||
    'unknown';

  const key = `resend:${ip}:${parsed.data.email}`;
  const limit = rateLimit(key, AUTH_RATE_LIMIT_CONFIG);

  if (!limit.allowed) {
    return NextResponse.json(
      {
        code: AUTH_ERROR_CODES.TOO_MANY_REQUESTS,
      },
      { status: 429 },
    );
  }

  try {
    await resendVerification(parsed.data.email);

    return NextResponse.json({ success: true }, { status: 200 });
  } catch (error) {
    if (error instanceof Error && error.message === AUTH_ERROR_CODES.EMAIL_ALREADY_VERIFIED) {
      return NextResponse.json(
        {
          code: AUTH_ERROR_CODES.EMAIL_ALREADY_VERIFIED,
        },
        { status: 400 },
      );
    }

    return NextResponse.json(
      {
        code: AUTH_ERROR_CODES.UNKNOWN_ERROR,
      },
      { status: 500 },
    );
  }
}
