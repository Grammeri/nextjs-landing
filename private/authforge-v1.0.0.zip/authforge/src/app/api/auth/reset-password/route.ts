import { NextResponse } from 'next/server';

import {
  resetPassword,
  isPasswordPwned,
  makeResetPasswordServerSchema,
} from '@/features/auth/server';

import { getDictionary } from '@/shared/i18n/getDictionary';
import { rateLimit } from '@/shared/security/rate-limit';
import { AUTH_RATE_LIMIT_CONFIG } from '@/shared/config/auth.constants';

export const runtime = 'nodejs';

export async function POST(req: Request) {
  const headers = req.headers;

  const ip =
    headers.get('x-forwarded-for')?.split(',')[0]?.trim() || headers.get('x-real-ip') || 'unknown';

  const limit = rateLimit(`reset:${ip}`, AUTH_RATE_LIMIT_CONFIG);

  if (!limit.allowed) {
    return NextResponse.json(
      { message: 'RATE_LIMIT_EXCEEDED' },
      { status: 429, headers: { 'Cache-Control': 'no-store' } },
    );
  }

  const body = await req.json().catch(() => null);

  const url = new URL(req.url);
  const queryToken = url.searchParams.get('token');

  const token = body?.token ?? queryToken;
  const newPassword = body?.newPassword;

  if (
    !body ||
    typeof body !== 'object' ||
    typeof token !== 'string' ||
    typeof newPassword !== 'string'
  ) {
    return NextResponse.json(
      { message: 'VALIDATION_ERROR' },
      { status: 400, headers: { 'Cache-Control': 'no-store' } },
    );
  }

  const dict = await getDictionary();
  const resetPasswordSchema = makeResetPasswordServerSchema(dict.auth.errors);

  const parsed = resetPasswordSchema.safeParse({
    newPassword,
  });

  if (!parsed.success) {
    return NextResponse.json(
      {
        message: 'VALIDATION_ERROR',
        errors: parsed.error.issues,
      },
      { status: 400, headers: { 'Cache-Control': 'no-store' } },
    );
  }

  try {
    const isPwned = await isPasswordPwned(parsed.data.newPassword);

    if (isPwned) {
      return NextResponse.json(
        { message: 'PASSWORD_PWNED' },
        { status: 400, headers: { 'Cache-Control': 'no-store' } },
      );
    }

    await resetPassword(token, parsed.data.newPassword);

    return NextResponse.json(
      { success: true },
      { status: 200, headers: { 'Cache-Control': 'no-store' } },
    );
  } catch (error) {
    if (error instanceof Error && error.message === 'INVALID_RESET_TOKEN') {
      return NextResponse.json(
        { message: 'INVALID_RESET_TOKEN' },
        { status: 400, headers: { 'Cache-Control': 'no-store' } },
      );
    }

    return NextResponse.json(
      { message: 'UNKNOWN_ERROR' },
      { status: 500, headers: { 'Cache-Control': 'no-store' } },
    );
  }
}
