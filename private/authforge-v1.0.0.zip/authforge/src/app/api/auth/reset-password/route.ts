import { NextResponse } from 'next/server';
import { z } from 'zod';

import {
  AUTH_ERROR_CODES,
  isPasswordPwned,
  makeResetPasswordServerSchema,
  resetPassword,
} from '@/features/auth/server';
import { AUTH_RATE_LIMIT_CONFIG } from '@/shared/config/auth.constants';
import { getDictionary } from '@/shared/i18n/getDictionary';
import { rateLimit } from '@/shared/security/rate-limit';

export const runtime = 'nodejs';

const NO_STORE_HEADERS = {
  'Cache-Control': 'no-store',
};

const resetPasswordRequestSchema = z.object({
  token: z.string(),
  newPassword: z.string(),
});

export async function POST(req: Request) {
  const headers = req.headers;

  const ip =
    headers.get('x-forwarded-for')?.split(',')[0]?.trim() || headers.get('x-real-ip') || 'unknown';

  const limit = rateLimit(`reset:${ip}`, AUTH_RATE_LIMIT_CONFIG);

  if (!limit.allowed) {
    return NextResponse.json(
      {
        code: AUTH_ERROR_CODES.TOO_MANY_REQUESTS,
      },
      { status: 429, headers: NO_STORE_HEADERS },
    );
  }

  const body = await req.json().catch(() => null);

  if (!body || typeof body !== 'object') {
    return NextResponse.json(
      {
        code: AUTH_ERROR_CODES.INVALID_JSON_PAYLOAD,
      },
      { status: 400, headers: NO_STORE_HEADERS },
    );
  }

  const url = new URL(req.url);
  const queryToken = url.searchParams.get('token');

  const normalizedInput = {
    token: body.token ?? queryToken,
    newPassword: body.newPassword,
  };

  const requestParsed = resetPasswordRequestSchema.safeParse(normalizedInput);

  if (!requestParsed.success) {
    return NextResponse.json(
      {
        code: AUTH_ERROR_CODES.VALIDATION_ERROR,
        errors: requestParsed.error.issues,
      },
      { status: 400, headers: NO_STORE_HEADERS },
    );
  }

  const { token, newPassword } = requestParsed.data;

  const dict = await getDictionary();
  const resetPasswordSchema = makeResetPasswordServerSchema(dict.auth.errors);

  const parsed = resetPasswordSchema.safeParse({
    newPassword,
  });

  if (!parsed.success) {
    return NextResponse.json(
      {
        code: AUTH_ERROR_CODES.VALIDATION_ERROR,
        errors: parsed.error.issues,
      },
      { status: 400, headers: NO_STORE_HEADERS },
    );
  }

  try {
    const isPwned = await isPasswordPwned(parsed.data.newPassword);

    if (isPwned) {
      return NextResponse.json(
        {
          code: AUTH_ERROR_CODES.PASSWORD_PWNED,
        },
        { status: 400, headers: NO_STORE_HEADERS },
      );
    }

    await resetPassword(token, parsed.data.newPassword);

    return NextResponse.json({ success: true }, { status: 200, headers: NO_STORE_HEADERS });
  } catch (error) {
    if (error instanceof Error && error.message === AUTH_ERROR_CODES.INVALID_RESET_TOKEN) {
      return NextResponse.json(
        {
          code: AUTH_ERROR_CODES.INVALID_RESET_TOKEN,
        },
        { status: 400, headers: NO_STORE_HEADERS },
      );
    }

    return NextResponse.json(
      {
        code: AUTH_ERROR_CODES.UNKNOWN_ERROR,
      },
      { status: 500, headers: NO_STORE_HEADERS },
    );
  }
}
