import { NextResponse } from 'next/server';
import { verifyEmail } from '@/features/auth/server';
import { rateLimit } from '@/shared/security/rate-limit';
import { AUTH_RATE_LIMIT_CONFIG } from '@/shared/config/auth.constants';

export const runtime = 'nodejs';

export async function POST(request: Request) {
  const headers = request.headers;

  const ip =
    headers.get('x-forwarded-for')?.split(',')[0]?.trim() || headers.get('x-real-ip') || 'unknown';

  const limit = rateLimit(`verify:${ip}`, AUTH_RATE_LIMIT_CONFIG);

  if (!limit.allowed) {
    return NextResponse.json(
      { message: 'RATE_LIMIT_EXCEEDED' },
      {
        status: 429,
        headers: {
          'Cache-Control': 'no-store',
        },
      },
    );
  }

  const body = await request.json().catch(() => null);

  if (!body || typeof body !== 'object' || typeof body.token !== 'string') {
    return NextResponse.json(
      { message: 'VALIDATION_ERROR' },
      {
        status: 400,
        headers: {
          'Cache-Control': 'no-store',
        },
      },
    );
  }

  try {
    await verifyEmail(body.token);

    return NextResponse.json(
      { success: true },
      {
        status: 200,
        headers: {
          'Cache-Control': 'no-store',
        },
      },
    );
  } catch (error) {
    if (!(error instanceof Error)) {
      return NextResponse.json(
        { message: 'UNKNOWN_ERROR' },
        {
          status: 500,
          headers: {
            'Cache-Control': 'no-store',
          },
        },
      );
    }

    switch (error.message) {
      case 'INVALID_VERIFICATION_TOKEN':
        return NextResponse.json(
          { message: 'INVALID_VERIFICATION_TOKEN' },
          {
            status: 400,
            headers: {
              'Cache-Control': 'no-store',
            },
          },
        );

      case 'TOKEN_ALREADY_USED':
        return NextResponse.json(
          { message: 'TOKEN_ALREADY_USED' },
          {
            status: 410,
            headers: {
              'Cache-Control': 'no-store',
            },
          },
        );

      case 'TOKEN_EXPIRED':
        return NextResponse.json(
          { message: 'TOKEN_EXPIRED' },
          {
            status: 410,
            headers: {
              'Cache-Control': 'no-store',
            },
          },
        );

      default:
        return NextResponse.json(
          { message: 'UNKNOWN_ERROR' },
          {
            status: 500,
            headers: {
              'Cache-Control': 'no-store',
            },
          },
        );
    }
  }
}
