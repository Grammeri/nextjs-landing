import { NextResponse } from 'next/server';
import { z } from 'zod';

import { AUTH_ERROR_CODES, verifyEmail } from '@/features/auth/server';
import { AUTH_RATE_LIMIT_CONFIG } from '@/shared/config/auth.constants';
import { rateLimit } from '@/shared/security/rate-limit';

export const runtime = 'nodejs';

const NO_STORE_HEADERS = {
  'Cache-Control': 'no-store',
};

const verifyEmailRequestSchema = z.object({
  token: z.string(),
});

export async function POST(request: Request) {
  const headers = request.headers;

  const ip =
    headers.get('x-forwarded-for')?.split(',')[0]?.trim() || headers.get('x-real-ip') || 'unknown';

  const limit = rateLimit(`verify:${ip}`, AUTH_RATE_LIMIT_CONFIG);

  if (!limit.allowed) {
    return NextResponse.json(
      {
        code: AUTH_ERROR_CODES.TOO_MANY_REQUESTS,
      },
      {
        status: 429,
        headers: NO_STORE_HEADERS,
      },
    );
  }

  const body = await request.json().catch(() => null);

  if (!body || typeof body !== 'object') {
    return NextResponse.json(
      {
        code: AUTH_ERROR_CODES.INVALID_JSON_PAYLOAD,
      },
      {
        status: 400,
        headers: NO_STORE_HEADERS,
      },
    );
  }

  const parsed = verifyEmailRequestSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      {
        code: AUTH_ERROR_CODES.VALIDATION_ERROR,
        errors: parsed.error.issues,
      },
      {
        status: 400,
        headers: NO_STORE_HEADERS,
      },
    );
  }

  try {
    await verifyEmail(parsed.data.token);

    return NextResponse.json(
      { success: true },
      {
        status: 200,
        headers: NO_STORE_HEADERS,
      },
    );
  } catch (error) {
    if (!(error instanceof Error)) {
      return NextResponse.json(
        {
          code: AUTH_ERROR_CODES.UNKNOWN_ERROR,
        },
        {
          status: 500,
          headers: NO_STORE_HEADERS,
        },
      );
    }

    switch (error.message) {
      case AUTH_ERROR_CODES.INVALID_VERIFICATION_TOKEN:
        return NextResponse.json(
          {
            code: AUTH_ERROR_CODES.INVALID_VERIFICATION_TOKEN,
          },
          {
            status: 400,
            headers: NO_STORE_HEADERS,
          },
        );

      case AUTH_ERROR_CODES.TOKEN_ALREADY_USED:
        return NextResponse.json(
          {
            code: AUTH_ERROR_CODES.TOKEN_ALREADY_USED,
          },
          {
            status: 410,
            headers: NO_STORE_HEADERS,
          },
        );

      case AUTH_ERROR_CODES.TOKEN_EXPIRED:
        return NextResponse.json(
          {
            code: AUTH_ERROR_CODES.TOKEN_EXPIRED,
          },
          {
            status: 410,
            headers: NO_STORE_HEADERS,
          },
        );

      default:
        return NextResponse.json(
          {
            code: AUTH_ERROR_CODES.UNKNOWN_ERROR,
          },
          {
            status: 500,
            headers: NO_STORE_HEADERS,
          },
        );
    }
  }
}
