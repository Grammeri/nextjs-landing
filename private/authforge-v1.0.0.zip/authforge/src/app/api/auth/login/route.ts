import { z } from 'zod';
import { NextResponse } from 'next/server';

import { loginUser, makeLoginSchema } from '@/features/auth/server';
import { ACCESS_SESSION_TTL_MINUTES } from '@/shared/config/auth.constants';
import { getDictionary } from '@/shared/i18n/getDictionary';
import { rateLimit } from '@/shared/security/rate-limit';
import { AUTH_RATE_LIMIT_CONFIG, SESSION_COOKIE_NAME } from '@/shared/config/auth.constants';

export const runtime = 'nodejs';

export async function POST(req: Request) {
  try {
    const body = await req.json();

    const dict = await getDictionary();
    const loginSchema = makeLoginSchema(dict.auth.errors);

    const input = loginSchema.parse(body);

    const ip = req.headers.get('x-forwarded-for') ?? req.headers.get('x-real-ip') ?? 'unknown';

    const key = `login:${ip}:${input.email}`;

    const limit = rateLimit(key, AUTH_RATE_LIMIT_CONFIG);

    if (!limit.allowed) {
      return NextResponse.json(
        { code: 'TOO_MANY_REQUESTS', message: 'Too many attempts' },
        { status: 429 },
      );
    }

    const result = await loginUser(input);

    const safeUser = {
      id: result.user.id,
      email: result.user.email,
    };

    const response = NextResponse.json(safeUser, { status: 200 });

    response.cookies.set(SESSION_COOKIE_NAME, result.session.sessionId, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      maxAge: ACCESS_SESSION_TTL_MINUTES * 60,
    });

    return response;
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ message: 'Invalid input' }, { status: 400 });
    }

    if (error instanceof Error && error.message === 'INVALID_CREDENTIALS') {
      return NextResponse.json({ message: 'Invalid credentials' }, { status: 401 });
    }

    return NextResponse.json({ message: 'Something went wrong' }, { status: 500 });
  }
}
