import { NextResponse } from 'next/server';

import { AUTH_ERROR_CODES, loginUser, makeLoginSchema } from '@/features/auth/server';
import {
  ACCESS_SESSION_TTL_MINUTES,
  AUTH_RATE_LIMIT_CONFIG,
  SESSION_COOKIE_NAME,
} from '@/shared/config/auth.constants';
import { getDictionary } from '@/shared/i18n/getDictionary';
import { rateLimit } from '@/shared/security/rate-limit';

export const runtime = 'nodejs';

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);

  if (!body || typeof body !== 'object') {
    return NextResponse.json(
      {
        code: AUTH_ERROR_CODES.INVALID_JSON_PAYLOAD,
      },
      { status: 400 },
    );
  }

  const dict = await getDictionary();
  const loginSchema = makeLoginSchema(dict.auth.errors);

  const parsed = loginSchema.safeParse(body);

  if (!parsed.success) {
    return NextResponse.json(
      {
        code: AUTH_ERROR_CODES.VALIDATION_ERROR,
        errors: parsed.error.issues,
      },
      { status: 400 },
    );
  }

  try {
    const ip =
      req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
      req.headers.get('x-real-ip') ||
      'unknown';

    const key = `login:${ip}:${parsed.data.email}`;

    const limit = rateLimit(key, AUTH_RATE_LIMIT_CONFIG);

    if (!limit.allowed) {
      return NextResponse.json(
        {
          code: AUTH_ERROR_CODES.TOO_MANY_REQUESTS,
        },
        { status: 429 },
      );
    }

    const result = await loginUser(parsed.data);

    const response = NextResponse.json({ success: true }, { status: 200 });

    response.cookies.set(SESSION_COOKIE_NAME, result.session.sessionId, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax',
      path: '/',
      maxAge: ACCESS_SESSION_TTL_MINUTES * 60,
    });

    return response;
  } catch (error) {
    if (error instanceof Error && error.message === AUTH_ERROR_CODES.INVALID_CREDENTIALS) {
      return NextResponse.json(
        {
          code: AUTH_ERROR_CODES.INVALID_CREDENTIALS,
        },
        { status: 401 },
      );
    }

    return NextResponse.json(
      {
        code: AUTH_ERROR_CODES.UNKNOWN_ERROR,
      },
      { status: 500 },
    );
  }
}
