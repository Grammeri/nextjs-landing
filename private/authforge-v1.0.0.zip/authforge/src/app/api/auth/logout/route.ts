import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';

import { logoutSession } from '@/features/auth/server';
import { SESSION_COOKIE_NAME } from '@/shared/config/auth.constants';

export const runtime = 'nodejs';

export async function POST() {
  const cookieStore = await cookies();
  const sessionId = cookieStore.get(SESSION_COOKIE_NAME)?.value;

  try {
    if (sessionId) {
      await logoutSession(sessionId);
    }
  } catch {
    // optional: add server-side logging here later
  }

  const response = NextResponse.json({ success: true }, { status: 200 });

  response.cookies.set(SESSION_COOKIE_NAME, '', {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: 0,
  });

  return response;
}
