import 'server-only';

import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';

import { logoutSession } from '@/features/auth/server';
import { SESSION_COOKIE_NAME } from '@/shared/config/auth.constants';

export const runtime = 'nodejs';

export async function POST() {
  const cookieStore = await cookies();
  const sessionId = cookieStore.get(SESSION_COOKIE_NAME)?.value;

  if (sessionId) {
    await logoutSession(sessionId);
  }

  const response = NextResponse.json({ success: true });

  response.cookies.set(SESSION_COOKIE_NAME, '', {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: 0,
  });

  return response;
}
