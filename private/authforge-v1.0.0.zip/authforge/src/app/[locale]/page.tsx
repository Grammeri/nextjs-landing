import { redirect, notFound } from 'next/navigation';
import { isLocale } from '@/shared/i18n/config';
import type { LocalePageProps } from '@/shared/types/next-locale';

export default async function LocalePage({ params }: LocalePageProps) {
  const { locale } = await params;

  if (!isLocale(locale)) {
    notFound();
  }

  redirect(`/${locale}/login`);
}
