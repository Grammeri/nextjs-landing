import { LoginForm } from '@/features/auth/public';
import { AuthHeader } from '@/shared/ui/AuthHeader/AuthHeader';
import { getDictionary } from '@/shared/i18n/getDictionary';
import { isLocale } from '@/shared/i18n/config';
import { notFound } from 'next/navigation';
import type { LocalePageProps } from '@/shared/types/next-locale';

export default async function LoginPage({ params }: LocalePageProps) {
  const { locale } = await params;

  if (!isLocale(locale)) {
    notFound();
  }

  const dict = await getDictionary();

  return (
    <>
      <AuthHeader title={dict.auth.login.title} />

      <LoginForm
        dict={dict.auth.login}
        commonDict={dict.auth.common}
        errorsDict={dict.auth.errors}
        locale={locale}
      />
    </>
  );
}
