import { DemoBackLink } from '@/shared/ui/DemoBackLink/DemoBackLink';
import styles from './layout.module.css';

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className={styles.authWrapper}>
      <div className={styles.authShell}>
        <DemoBackLink />
        <div className={styles.authCard}>{children}</div>
      </div>
    </div>
  );
}
