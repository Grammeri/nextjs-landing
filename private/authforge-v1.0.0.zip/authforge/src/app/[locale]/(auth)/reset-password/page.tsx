import { ResetPasswordForm } from '@/features/auth/public';
import { AuthHeader } from '@/shared/ui/AuthHeader/AuthHeader';
import { getDictionary } from '@/shared/i18n/getDictionary';
import { isLocale } from '@/shared/i18n/config';
import { notFound } from 'next/navigation';
import type { LocalePageProps } from '@/shared/types/next-locale';

interface ResetPasswordPageProps extends LocalePageProps {
  searchParams: Promise<{
    token?: string;
  }>;
}

export default async function ResetPasswordPage({ params, searchParams }: ResetPasswordPageProps) {
  const { locale } = await params;

  if (!isLocale(locale)) {
    notFound();
  }

  const dict = await getDictionary();
  const { token } = await searchParams;

  const isDemoMode = process.env.AUTH_DEMO_MODE === 'true';

  // ❗ Production: token обязателен
  if (!token && !isDemoMode) {
    return (
      <>
        <AuthHeader
          title={dict.auth.reset.invalidLinkTitle}
          description={dict.auth.reset.invalidLinkMessage}
        />
      </>
    );
  }

  return (
    <>
      <AuthHeader title={dict.auth.reset.title} description={dict.auth.reset.description} />

      <ResetPasswordForm
        token={token ?? 'demo-reset-token'}
        dict={dict.auth.reset}
        errorsDict={dict.auth.errors}
        locale={locale}
      />
    </>
  );
}
