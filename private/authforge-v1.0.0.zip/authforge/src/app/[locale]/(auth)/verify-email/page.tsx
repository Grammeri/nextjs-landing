import { redirect, notFound } from 'next/navigation';
import { isLocale } from '@/shared/i18n/config';
import { verifyEmail } from '@/features/auth/server';
import type { LocalePageProps } from '@/shared/types/next-locale';

interface VerifyEmailPageProps extends LocalePageProps {
  searchParams: Promise<{
    token?: string;
  }>;
}

export default async function VerifyEmailPage({ params, searchParams }: VerifyEmailPageProps) {
  const { locale } = await params;
  const resolvedSearchParams = await searchParams;
  const { token } = resolvedSearchParams;

  if (!isLocale(locale)) {
    notFound();
  }

  if (!token) {
    redirect(`/${locale}/login`);
  }

  try {
    await verifyEmail(token);
  } catch {}

  redirect(`/${locale}/login`);
}
