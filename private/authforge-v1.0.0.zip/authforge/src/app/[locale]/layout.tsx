import { notFound } from 'next/navigation';
import { isLocale } from '@/shared/i18n/config';
import type { LocaleLayoutProps } from '@/shared/types/next-locale';

export default async function LocaleLayout({ children, params }: LocaleLayoutProps) {
  const { locale } = await params;

  if (!isLocale(locale)) {
    notFound();
  }

  return <>{children}</>;
}
