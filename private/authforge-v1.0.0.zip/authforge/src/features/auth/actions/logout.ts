'use server';

import { redirect } from 'next/navigation';
import { cookies } from 'next/headers';

import { logoutSession } from '../model/auth.service';
import { SESSION_COOKIE_NAME } from '@/shared/config/auth.constants';

export async function logout() {
  const cookieStore = await cookies();
  const sessionId = cookieStore.get(SESSION_COOKIE_NAME)?.value;

  if (sessionId) {
    await logoutSession(sessionId);
  }

  // Always expire session cookie to prevent reuse
  cookieStore.set(SESSION_COOKIE_NAME, '', {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: 0,
  });

  redirect('/login');
}
