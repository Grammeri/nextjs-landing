'use client';

import { useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';

import { makeRegisterSchema, type RegisterFormValues } from '../../model/register.schema';
import type { Dictionary } from '@/shared/i18n/getDictionary';

export function useRegisterForm(errors: Dictionary['auth']['errors']) {
  const schema = useMemo(() => makeRegisterSchema(errors), [errors]);

  return useForm<RegisterFormValues>({
    resolver: zodResolver(schema),
    mode: 'onTouched',
    reValidateMode: 'onChange',
    shouldFocusError: true,
    defaultValues: {
      email: '',
      password: '',
      confirmPassword: '',
    },
  });
}
