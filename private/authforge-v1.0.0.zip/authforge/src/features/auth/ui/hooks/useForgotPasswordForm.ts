'use client';

import { useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';

import { makeForgotPasswordSchema } from '../../model/forgot-password.schema';
import type { ForgotPasswordFormValues } from '../../model/forgot-password.schema';
import type { Dictionary } from '@/shared/i18n/getDictionary';

export function useForgotPasswordForm(errors: Dictionary['auth']['errors']) {
  const schema = useMemo(() => makeForgotPasswordSchema(errors), [errors]);

  return useForm<ForgotPasswordFormValues>({
    resolver: zodResolver(schema),
    mode: 'onTouched',
    reValidateMode: 'onChange',
    shouldFocusError: true,
    defaultValues: {
      email: '',
    },
  });
}
