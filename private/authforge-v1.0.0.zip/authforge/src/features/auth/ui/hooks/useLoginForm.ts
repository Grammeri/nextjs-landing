'use client';

import { useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';

import { makeLoginSchema, type LoginFormValues } from '../../model/login.schema';
import type { Dictionary } from '@/shared/i18n/getDictionary';

export function useLoginForm(errors: Dictionary['auth']['errors']) {
  const schema = useMemo(() => makeLoginSchema(errors), [errors]);

  return useForm<LoginFormValues>({
    resolver: zodResolver(schema),

    mode: 'onTouched',
    reValidateMode: 'onChange',

    shouldFocusError: true,

    defaultValues: {
      email: '',
      password: '',
    },
  });
}
