'use client';

import { useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';

import {
  makeResetPasswordSchema,
  type ResetPasswordFormValues,
} from '../../model/reset-password.schema';

import type { Dictionary } from '@/shared/i18n/getDictionary';

export function useResetPasswordForm(errors: Dictionary['auth']['errors']) {
  const schema = useMemo(() => makeResetPasswordSchema(errors), [errors]);

  return useForm<ResetPasswordFormValues>({
    resolver: zodResolver(schema),
    mode: 'onTouched',
    reValidateMode: 'onChange',
    shouldFocusError: true,
    defaultValues: {
      newPassword: '',
      confirmPassword: '',
    },
  });
}
