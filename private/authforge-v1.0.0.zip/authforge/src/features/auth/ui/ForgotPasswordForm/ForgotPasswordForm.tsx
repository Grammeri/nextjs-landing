'use client';

import { useState } from 'react';
import Link from 'next/link';
import { FormLink } from '@/shared/ui/FormLink/FormLink';
import { FormFooter } from '@/shared/ui/FormFooter/FormFooter';

import { useForgotPasswordForm } from '../hooks/useForgotPasswordForm';
import { requestPasswordReset } from '../../api/auth.api';
import type { ForgotPasswordFormValues } from '../../model/forgot-password.schema';
import { getLoginPath } from '../../config/auth.routes';

import { ApiError } from '@/shared/api/apiFetch';

import { Input } from '@/shared/ui/Input/Input';
import { Button } from '@/shared/ui/Button/Button';
import { FormError } from '@/shared/ui/FormError/FormError';
import { Form } from '@/shared/ui/Form/Form';

import type { Dictionary } from '@/shared/i18n/getDictionary';
import type { Locale } from '@/shared/i18n/config';

import styles from './ForgotPasswordForm.module.css';

type ForgotPasswordFormProps = {
  dict: Dictionary['auth']['forgot'];
  errorsDict: Dictionary['auth']['errors'];
  locale: Locale;
};

export function ForgotPasswordForm({ dict, errorsDict, locale }: ForgotPasswordFormProps) {
  const form = useForgotPasswordForm(errorsDict);

  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [demoResetPasswordUrl, setDemoResetPasswordUrl] = useState<string | null>(null);

  const onSubmit = async ({ email }: ForgotPasswordFormValues) => {
    setError(null);

    try {
      const result = await requestPasswordReset(email);

      if (
        result &&
        typeof result === 'object' &&
        'demoResetPasswordUrl' in result &&
        typeof result.demoResetPasswordUrl === 'string' &&
        result.demoResetPasswordUrl.length > 0
      ) {
        setDemoResetPasswordUrl(result.demoResetPasswordUrl);
      }

      setSuccess(true);
    } catch (err: unknown) {
      if (err instanceof ApiError) {
        if (err.status === 429) {
          setError(errorsDict.tooManyAttempts);
          return;
        }

        if (err.status >= 500) {
          setError(errorsDict.generic);
          return;
        }

        setError(errorsDict.generic);
        return;
      }

      setError(errorsDict.generic);
    }
  };

  if (success) {
    return (
      <div className={styles.form}>
        <p className={styles.successMessage}>{dict.successMessage}</p>

        {demoResetPasswordUrl && (
          <div className={styles.demoContainer}>
            <p className={styles.demoLabel}>{dict.demoLabel}</p>

            <Link href={demoResetPasswordUrl}>
              <Button>{dict.demoButton}</Button>
            </Link>
          </div>
        )}

        <FormFooter>
          <FormLink href={getLoginPath(locale)}>{dict.backToLogin}</FormLink>
        </FormFooter>
      </div>
    );
  }

  return (
    <Form className={styles.form} onSubmit={form.handleSubmit(onSubmit)}>
      <Input
        label={dict.emailLabel}
        type="email"
        placeholder={dict.emailPlaceholder}
        autoComplete="email"
        error={form.formState.errors.email?.message}
        {...form.register('email', {
          onChange: () => {
            if (error) setError(null);
            if (success) setSuccess(false);
            if (demoResetPasswordUrl) setDemoResetPasswordUrl(null);
          },
        })}
      />

      <Button type="submit" loading={form.formState.isSubmitting}>
        {dict.submit}
      </Button>

      {error && <FormError>{error}</FormError>}

      <FormFooter>
        <FormLink href={getLoginPath(locale)}>{dict.backToLogin}</FormLink>
      </FormFooter>
    </Form>
  );
}
