'use client';

import { useState } from 'react';
import { FormLink } from '@/shared/ui/FormLink/FormLink';
import { useRouter } from 'next/navigation';
import { notify } from '@/shared/lib/notify/notify';

import { useLoginForm } from '../hooks/useLoginForm';
import { login } from '../../api/auth.api';
import type { LoginFormValues } from '../../model/login.schema';
import {
  getAfterLoginPath,
  getForgotPasswordPath,
  getRegisterPath,
} from '../../config/auth.routes';

import { Input } from '@/shared/ui/Input/Input';
import { Button } from '@/shared/ui/Button/Button';
import { FormError } from '@/shared/ui/FormError/FormError';
import { Form } from '@/shared/ui/Form/Form';
import { ApiError } from '@/shared/api/apiFetch';
import type { Dictionary } from '@/shared/i18n/getDictionary';
import type { Locale } from '@/shared/i18n/config';

import styles from './LoginForm.module.css';

type LoginFormProps = {
  dict: Dictionary['auth']['login'];
  commonDict: Dictionary['auth']['common'];
  errorsDict: Dictionary['auth']['errors'];
  locale: Locale;
  onSuccess?: () => void;
};

export function LoginForm({ dict, commonDict, errorsDict, locale, onSuccess }: LoginFormProps) {
  const router = useRouter();
  const form = useLoginForm(errorsDict);
  const [error, setError] = useState<string | null>(null);

  const onSubmit = async (values: LoginFormValues) => {
    setError(null);

    try {
      await login(values);
      notify.success(dict.successMessage);

      if (onSuccess) {
        onSuccess();
        return;
      }

      router.push(getAfterLoginPath(locale));
    } catch (e: unknown) {
      if (e instanceof ApiError) {
        switch (e.status) {
          case 401:
            setError(errorsDict.invalidCredentials);
            return;
          case 429:
            setError(errorsDict.tooManyAttempts);
            return;
          case 403:
            setError(errorsDict.generic);
            return;
          default:
            if (e.status >= 500) {
              setError(errorsDict.generic);
              return;
            }
        }

        setError(errorsDict.generic);
        return;
      }

      setError(errorsDict.generic);
    }
  };

  return (
    <Form className={styles.form} onSubmit={form.handleSubmit(onSubmit)}>
      <Input
        label={dict.emailLabel}
        type="email"
        placeholder={commonDict.emailPlaceholder}
        autoComplete="email"
        error={form.formState.errors.email?.message}
        {...form.register('email', {
          onChange: () => {
            if (error) setError(null);
          },
        })}
      />
      <Input
        label={dict.passwordLabel}
        type="password"
        autoComplete="current-password"
        error={form.formState.errors.password?.message}
        showPasswordToggle
        showPasswordText={commonDict.showPassword}
        hidePasswordText={commonDict.hidePassword}
        {...form.register('password', {
          onChange: () => {
            if (error) setError(null);
          },
        })}
      />
      <div className={styles.forgotWrapper}>
        <FormLink href={getForgotPasswordPath(locale)}>{dict.forgotLink}</FormLink>
      </div>

      <Button type="submit" loading={form.formState.isSubmitting}>
        {dict.submit}
      </Button>

      {error && <FormError>{error}</FormError>}

      <div className={styles.footer}>
        {dict.noAccount} <FormLink href={getRegisterPath(locale)}>{dict.registerLink}</FormLink>
      </div>
    </Form>
  );
}
