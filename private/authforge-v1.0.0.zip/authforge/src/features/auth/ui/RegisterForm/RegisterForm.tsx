'use client';

import { useState } from 'react';
import { FormLink } from '@/shared/ui/FormLink/FormLink';
import { useRegisterForm } from '../hooks/useRegisterForm';
import { register } from '../../api/auth.api';
import type { RegisterFormValues } from '../../model/register.schema';

import { ApiError } from '@/shared/api/apiFetch';
import { mapBackendError } from '../../lib/mapBackendError';

import { Input } from '@/shared/ui/Input/Input';
import { Button } from '@/shared/ui/Button/Button';
import { FormError } from '@/shared/ui/FormError/FormError';
import { Form } from '@/shared/ui/Form/Form';
import { PasswordStrengthBar } from '../PasswordStrengthBar/PasswordStrengthBar';
import type { Locale } from '@/shared/i18n/config';
import type { Dictionary } from '@/shared/i18n/getDictionary';

import styles from './RegisterForm.module.css';

type RegisterFormProps = {
  dict: Dictionary['auth']['register'];
  commonDict: Dictionary['auth']['common'];
  errorsDict: Dictionary['auth']['errors'];
  locale: Locale;
};

function isDemoVerificationResult(value: unknown): value is { demoVerificationUrl: string } {
  if (!value || typeof value !== 'object') return false;
  if (!('demoVerificationUrl' in value)) return false;
  return typeof (value as { demoVerificationUrl?: unknown }).demoVerificationUrl === 'string';
}

export function RegisterForm({ dict, commonDict, errorsDict, locale }: RegisterFormProps) {
  const form = useRegisterForm(errorsDict);

  const [error, setError] = useState<string | null>(null);
  const [demoVerificationUrl, setDemoVerificationUrl] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const passwordValue = form.watch('password');

  const clearServerState = () => {
    if (error) setError(null);
    if (demoVerificationUrl) setDemoVerificationUrl(null);
  };

  const onSubmit = async (values: RegisterFormValues) => {
    setError(null);
    setSuccess(false);
    setDemoVerificationUrl(null);

    try {
      const result = await register(values);

      if (isDemoVerificationResult(result) && result.demoVerificationUrl.length > 0) {
        setDemoVerificationUrl(result.demoVerificationUrl);
        return;
      }

      setSuccess(true);
    } catch (err: unknown) {
      if (err instanceof ApiError) {
        setError(mapBackendError(err.code, errorsDict));
        return;
      }

      setError(errorsDict.generic);
    }
  };

  if (success) {
    return (
      <div className={styles.successContainer}>
        <p className={styles.successMessage}>{dict.verificationEmailSent}</p>

        <div className={styles.footer}>
          <FormLink href={`/${locale}/login`}>{dict.loginLink}</FormLink>
        </div>
      </div>
    );
  }

  return (
    <Form onSubmit={form.handleSubmit(onSubmit)} className={styles.form} noValidate>
      <Input
        label={dict.emailLabel}
        type="email"
        placeholder={commonDict.emailPlaceholder}
        autoComplete="email"
        error={form.formState.errors.email?.message}
        {...form.register('email', {
          onChange: () => {
            clearServerState();
          },
        })}
      />

      <Input
        label={dict.passwordLabel}
        type="password"
        autoComplete="new-password"
        showPasswordToggle
        showPasswordText={commonDict.showPassword}
        hidePasswordText={commonDict.hidePassword}
        error={form.formState.errors.password?.message}
        {...form.register('password', {
          onChange: () => {
            clearServerState();
          },
        })}
      />

      <PasswordStrengthBar password={passwordValue ?? ''} />

      <Input
        label={dict.confirmPasswordLabel}
        type="password"
        autoComplete="new-password"
        showPasswordToggle
        showPasswordText={commonDict.showPassword}
        hidePasswordText={commonDict.hidePassword}
        error={form.formState.errors.confirmPassword?.message}
        {...form.register('confirmPassword', {
          onChange: () => {
            clearServerState();
          },
        })}
      />

      <Button type="submit" loading={form.formState.isSubmitting}>
        {dict.submit}
      </Button>

      {error && <FormError>{error}</FormError>}

      {demoVerificationUrl && (
        <div className={styles.demoBlock}>
          <p className={styles.demoText}>{dict.verificationNotice}</p>

          <a href={demoVerificationUrl} className={styles.demoButton} rel="noopener noreferrer">
            {dict.verifyDemoButton}
          </a>
        </div>
      )}

      <div className={styles.footer}>
        {dict.haveAccount} <FormLink href={`/${locale}/login`}>{dict.loginLink}</FormLink>
      </div>
    </Form>
  );
}
