'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { notify } from '@/shared/lib/notify/notify';

import { useResetPasswordForm } from '../hooks/useResetPasswordForm';
import { resetPassword } from '../../api/auth.api';
import { mapBackendError } from '../../lib/mapBackendError';
import type { ResetPasswordFormValues } from '../../model/reset-password.schema';
import { getLoginPath } from '../../config/auth.routes';

import { ApiError } from '@/shared/api/apiFetch';

import { Input } from '@/shared/ui/Input/Input';
import { Button } from '@/shared/ui/Button/Button';
import { Form } from '@/shared/ui/Form/Form';
import { FormError } from '@/shared/ui/FormError/FormError';
import { PasswordStrengthBar } from '../PasswordStrengthBar/PasswordStrengthBar';
import { FormFooter } from '@/shared/ui/FormFooter/FormFooter';
import { FormLink } from '@/shared/ui/FormLink/FormLink';

import type { Locale } from '@/shared/i18n/config';
import type { Dictionary } from '@/shared/i18n/getDictionary';

import styles from './ResetPasswordForm.module.css';

type ResetPasswordFormProps = {
  token: string;
  dict: Dictionary['auth']['reset'];
  errorsDict: Dictionary['auth']['errors'];
  locale: Locale;
};

export function ResetPasswordForm({ token, dict, errorsDict, locale }: ResetPasswordFormProps) {
  const form = useResetPasswordForm(errorsDict);
  const router = useRouter();

  const [error, setError] = useState<string | null>(null);

  const passwordValue = form.watch('newPassword');
  const loginPath = getLoginPath(locale);

  const onSubmit = async (values: ResetPasswordFormValues) => {
    setError(null);

    try {
      await resetPassword(token, values.newPassword);

      notify.success(dict.successMessage);
      router.push(loginPath);
    } catch (err: unknown) {
      if (err instanceof ApiError) {
        setError(mapBackendError(err.code, errorsDict));
        return;
      }

      setError(errorsDict.generic);
    }
  };

  return (
    <Form onSubmit={form.handleSubmit(onSubmit)} className={styles.form} noValidate>
      <Input
        label={dict.passwordLabel}
        type="password"
        autoComplete="new-password"
        error={form.formState.errors.newPassword?.message}
        showPasswordToggle
        showPasswordText={dict.showPassword}
        hidePasswordText={dict.hidePassword}
        {...form.register('newPassword', {
          onChange: () => {
            form.clearErrors('newPassword');
            if (error) setError(null);
          },
        })}
      />

      <PasswordStrengthBar password={passwordValue ?? ''} />

      <Input
        label={dict.confirmPasswordLabel}
        type="password"
        autoComplete="new-password"
        error={form.formState.errors.confirmPassword?.message}
        showPasswordToggle
        showPasswordText={dict.showPassword}
        hidePasswordText={dict.hidePassword}
        {...form.register('confirmPassword', {
          onChange: () => {
            form.clearErrors('confirmPassword');
            if (error) setError(null);
          },
        })}
      />

      <Button type="submit" loading={form.formState.isSubmitting}>
        {dict.submit}
      </Button>

      {error && <FormError>{error}</FormError>}

      <FormFooter>
        <FormLink href={loginPath}>{dict.backToLogin}</FormLink>
      </FormFooter>
    </Form>
  );
}
