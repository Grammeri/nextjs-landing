'use client';

import styles from './PasswordStrengthBar.module.css';
import { getPasswordStrength } from '../../lib/getPasswordStrength';

type Props = Readonly<{
  password: string;
}>;

export function PasswordStrengthBar({ password }: Props) {
  if (!password) return null;

  const { score, label } = getPasswordStrength(password);
  const normalizedScore = Math.min(Math.max(score, 0), 4);

  return (
    <div className={styles.wrapper}>
      <div className={styles.track}>
        <div className={`${styles.fill} ${styles[`level${normalizedScore}`]}`} />
      </div>

      <span className={styles.label}>{label}</span>
    </div>
  );
}
