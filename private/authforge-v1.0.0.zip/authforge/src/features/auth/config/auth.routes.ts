import type { Locale } from '@/shared/i18n/config';

/**
 * Auth route helpers.
 * Centralizes locale-aware auth paths used by UI components.
 */

export function getAfterLoginPath(locale: Locale): string {
  return `/${locale}`;
}

export function getLoginPath(locale: Locale): string {
  return `/${locale}/login`;
}

export function getRegisterPath(locale: Locale): string {
  return `/${locale}/register`;
}

export function getForgotPasswordPath(locale: Locale): string {
  return `/${locale}/forgot-password`;
}
