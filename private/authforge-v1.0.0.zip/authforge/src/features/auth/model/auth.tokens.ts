import { randomBytes, createHmac } from 'crypto';

import { env } from '@/shared/config/env';
import { defaultLocale } from '@/shared/i18n/config';
import { AUTH_TOKEN_BYTES, AUTH_TOKEN_TTL } from '@/shared/config/auth.constants';

/* ======================
   TOKEN TTL
====================== */

export const TOKEN_TTL = AUTH_TOKEN_TTL;

/* ======================
   TOKEN HELPERS
====================== */

export function generateToken(): string {
  return randomBytes(AUTH_TOKEN_BYTES).toString('base64url');
}

export function tokenToHash(token: string): string {
  return createHmac('sha256', env.AUTH_TOKEN_PEPPER).update(token).digest('hex');
}

/* ======================
   URL HELPERS
====================== */

function getAppUrl(): string {
  return env.APP_URL;
}

/**
 * Builds a locale-prefixed page URL using the default locale.
 * (Used for demo / fallback flows.)
 */
export function buildLocalePageUrl(path: string): string {
  return `${getAppUrl()}/${defaultLocale}${path}`;
}
