import { z } from 'zod';
import { makeEmailWithErrors } from './email.schema';
import type { Dictionary } from '@/shared/i18n/getDictionary';

export const makeLoginSchema = (errors: Dictionary['auth']['errors']) =>
  z.object({
    email: makeEmailWithErrors(errors),
    password: z.string().trim().nonempty(errors.passwordRequired),
  });

export type LoginFormValues = z.infer<ReturnType<typeof makeLoginSchema>>;
