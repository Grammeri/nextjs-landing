import { z } from 'zod';
import { makePasswordSchema } from './password.schema';
import type { Dictionary } from '@/shared/i18n/getDictionary';

/**
 * Factory for reset-password validation schema.
 *
 * - Enforces centralized password policy
 * - Ensures confirmation match
 * - Bound to localized error dictionary
 */
export const makeResetPasswordSchema = (errors: Dictionary['auth']['errors']) => {
  const passwordSchema = makePasswordSchema(errors);

  return z
    .object({
      newPassword: passwordSchema,
      confirmPassword: z.string().trim().nonempty(errors.confirmPasswordRequired),
    })
    .refine((data) => data.newPassword === data.confirmPassword, {
      message: errors.passwordsDoNotMatch,
      path: ['confirmPassword'],
    });
};

export type ResetPasswordFormValues = z.infer<ReturnType<typeof makeResetPasswordSchema>>;
