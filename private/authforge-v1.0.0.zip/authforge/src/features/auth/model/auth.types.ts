/**
 * Registration payload entering the auth domain.
 * Password is raw at this boundary and must be hashed in service layer.
 */
export interface CreateUserInput {
  email: string;
  password: string;
}

/**
 * Authentication payload entering the auth domain.
 */
export interface LoginInput {
  email: string;
  password: string;
}

/**
 * Public user projection returned by auth domain.
 *
 * Sensitive fields (passwordHash, tokens, security flags)
 * are intentionally excluded.
 */
export interface AuthUser {
  id: string;
  email: string;
  emailVerifiedAt: Date | null;
  createdAt: Date;
}

/**
 * Represents an ACCESS session issued by auth domain.
 */
export interface AuthSession {
  sessionId: string;
  userId: string;
  expiresAt: Date;
}

/**
 * Successful authentication result.
 * Returned by login / session validation flows.
 */
export interface AuthResult {
  user: AuthUser;
  session: AuthSession;
}
