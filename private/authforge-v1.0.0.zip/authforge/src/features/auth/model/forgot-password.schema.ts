import { z } from 'zod';
import { makeEmailSchema } from './email.schema';
import type { Dictionary } from '@/shared/i18n/getDictionary';

export const makeForgotPasswordSchema = (errors: Dictionary['auth']['errors']) =>
  z.object({
    email: makeEmailSchema({
      required: errors.emailRequired,
      invalid: errors.emailInvalid,
      ascii: errors.emailAscii,
    }),
  });

export type ForgotPasswordFormValues = {
  email: string;
};
