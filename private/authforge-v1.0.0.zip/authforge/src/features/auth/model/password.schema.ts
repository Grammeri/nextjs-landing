import { z } from 'zod';
import type { Dictionary } from '@/shared/i18n/getDictionary';
import { PASSWORD_MAX_LENGTH, PASSWORD_MIN_LENGTH } from '@/shared/config/auth.constants';

const MIN_LENGTH = PASSWORD_MIN_LENGTH;
const MAX_LENGTH = PASSWORD_MAX_LENGTH;

export const makePasswordSchema = (errors: Dictionary['auth']['errors']) =>
  z
    .string()
    .trim()
    .nonempty(errors.passwordRequired)
    .min(MIN_LENGTH, errors.passwordMinLength)
    .max(MAX_LENGTH, errors.passwordMaxLength)
    .regex(/\p{L}/u, errors.passwordLetter)
    .regex(/\p{Lu}/u, errors.passwordUppercase)
    .regex(/\p{Ll}/u, errors.passwordLowercase)
    .regex(/[0-9]/, errors.passwordNumber)
    .refine((val) => !/\s/.test(val), {
      message: errors.passwordNoSpaces,
    });
