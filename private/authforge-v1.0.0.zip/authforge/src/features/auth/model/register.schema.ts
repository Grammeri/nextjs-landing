import { z } from 'zod';
import { makePasswordSchema } from './password.schema';
import { makeEmailWithErrors } from './email.schema';
import type { Dictionary } from '@/shared/i18n/getDictionary';

export const makeRegisterSchema = (errors: Dictionary['auth']['errors']) => {
  const passwordSchema = makePasswordSchema(errors);

  return z
    .object({
      email: makeEmailWithErrors(errors),
      password: passwordSchema,
      confirmPassword: z.string().trim().nonempty(errors.confirmPasswordRequired),
    })
    .superRefine((data, ctx) => {
      if (data.password !== data.confirmPassword) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ['confirmPassword'],
          message: errors.passwordsDoNotMatch,
        });
      }
    });
};

export type RegisterFormValues = z.infer<ReturnType<typeof makeRegisterSchema>>;
