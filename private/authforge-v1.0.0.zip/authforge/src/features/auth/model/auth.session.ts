import { prisma } from '@corporate-saas/db';
import type { AuthUser } from './auth.types';

import {
  ACCESS_SESSION_TTL_MINUTES,
  REFRESH_SESSION_TTL_DAYS,
} from '@/shared/config/auth.constants';

const ACCESS_SESSION_TYPE = 'ACCESS';
const REFRESH_SESSION_TYPE = 'REFRESH';

/* ======================
   SESSION CREATION
====================== */

export async function createUserSessions(userId: string) {
  const now = Date.now();

  const accessExpiresAt = new Date(now + ACCESS_SESSION_TTL_MINUTES * 60 * 1000);
  const refreshExpiresAt = new Date(now + REFRESH_SESSION_TTL_DAYS * 24 * 60 * 60 * 1000);

  const [accessSession, refreshSession] = await prisma.$transaction([
    prisma.session.create({
      data: {
        userId,
        type: ACCESS_SESSION_TYPE,
        expiresAt: accessExpiresAt,
      },
    }),
    prisma.session.create({
      data: {
        userId,
        type: REFRESH_SESSION_TYPE,
        expiresAt: refreshExpiresAt,
      },
    }),
  ]);

  return { accessSession, refreshSession };
}

/* ======================
   SESSION REVOCATION
====================== */

export async function revokeSession(sessionId: string): Promise<void> {
  await prisma.session.update({
    where: { id: sessionId },
    data: { revokedAt: new Date() },
  });
}

export async function revokeAllUserSessions(userId: string): Promise<void> {
  await prisma.session.updateMany({
    where: { userId, revokedAt: null },
    data: { revokedAt: new Date() },
  });
}

/* ======================
   SESSION VALIDATION
====================== */

export async function validateSession(sessionId: string): Promise<AuthUser | null> {
  const session = await prisma.session.findUnique({
    where: { id: sessionId },
    select: {
      type: true,
      expiresAt: true,
      revokedAt: true,
      user: {
        select: {
          id: true,
          email: true,
          emailVerifiedAt: true,
          createdAt: true,
        },
      },
    },
  });

  if (!session) return null;
  if (session.type !== ACCESS_SESSION_TYPE) return null;
  if (session.revokedAt) return null;

  const now = Date.now();
  if (session.expiresAt.getTime() < now) return null;

  return {
    id: session.user.id,
    email: session.user.email,
    emailVerifiedAt: session.user.emailVerifiedAt,
    createdAt: session.user.createdAt,
  };
}
