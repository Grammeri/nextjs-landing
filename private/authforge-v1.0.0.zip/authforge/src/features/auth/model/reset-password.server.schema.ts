import { z } from 'zod';
import { makePasswordSchema } from './password.schema';
import type { Dictionary } from '@/shared/i18n/getDictionary';

export const makeResetPasswordServerSchema = (errors: Dictionary['auth']['errors']) => {
  return z.object({
    newPassword: makePasswordSchema(errors),
  });
};

export type ResetPasswordServerValues = z.infer<ReturnType<typeof makeResetPasswordServerSchema>>;
