import { PrismaClientKnownRequestError } from '@prisma/client/runtime/library';
import bcrypt from 'bcryptjs';

import { prisma } from '@corporate-saas/db';

import type { CreateUserInput, LoginInput, AuthResult, AuthUser, AuthSession } from './auth.types';

import { createUserSessions, revokeSession } from './auth.session';
import { PASSWORD_SALT_ROUNDS } from '@/shared/config/auth.constants';
import { getEmailProvider } from '../email/email.provider';
import { AuthError, AUTH_ERROR_CODES } from './auth.errors';
import { isDemoMode } from '@/shared/config/demo';

import { generateToken, tokenToHash, TOKEN_TTL, buildLocalePageUrl } from './auth.tokens';

/* ======================
   SECURITY CONFIG
====================== */

const SECURITY_CONFIG = {
  DUMMY_PASSWORD_HASH: '$2a$12$3vQ7c7f0nYJp7d8cC1v8jO9o4qPzWcS2c0wV8mM9bqkq4KQG2mQyS',
} as const;

/* ======================
   REGISTER
====================== */

export async function registerUser(
  input: CreateUserInput,
): Promise<{ success: true } | { status: 'verification_required'; demoVerificationUrl: string }> {
  const { email, password } = input;

  const existingUser = await prisma.user.findUnique({
    where: { email },
    select: { id: true, deletedAt: true },
  });

  if (existingUser && !existingUser.deletedAt) {
    throw new AuthError(AUTH_ERROR_CODES.EMAIL_ALREADY_EXISTS);
  }

  const passwordHash = await bcrypt.hash(password, PASSWORD_SALT_ROUNDS);

  let user: { id: string; email: string; emailVerifiedAt: Date | null; createdAt: Date };

  try {
    user = await prisma.user.create({
      data: { email, passwordHash },
      select: { id: true, email: true, emailVerifiedAt: true, createdAt: true },
    });
  } catch (error) {
    if ((error as PrismaClientKnownRequestError)?.code === 'P2002') {
      throw new AuthError(AUTH_ERROR_CODES.EMAIL_ALREADY_EXISTS);
    }
    throw error;
  }

  const rawToken = generateToken();
  const tokenHash = tokenToHash(rawToken);

  await prisma.emailVerificationToken.create({
    data: {
      userId: user.id,
      tokenHash,
      expiresAt: new Date(Date.now() + TOKEN_TTL.EMAIL_VERIFICATION_MS),
    },
  });

  if (isDemoMode()) {
    return {
      status: 'verification_required',
      demoVerificationUrl: buildLocalePageUrl(`/verify-email?token=${rawToken}`),
    };
  }

  const verifyUrl = buildLocalePageUrl(`/verify-email?token=${rawToken}`);

  try {
    const provider = getEmailProvider();

    await provider.send({
      to: user.email,
      subject: 'Verify your email',
      html: `<a href="${verifyUrl}">Verify email</a>`,
    });
  } catch {
    // deliberately silent (do not leak email infra errors)
  }

  return { success: true };
}

/* ======================
   LOGIN (timing safe)
====================== */

export async function loginUser(input: LoginInput): Promise<AuthResult> {
  const { email, password } = input;

  const user = await prisma.user.findUnique({
    where: { email },
    select: {
      id: true,
      email: true,
      passwordHash: true,
      deletedAt: true,
      emailVerifiedAt: true,
      createdAt: true,
    },
  });

  const hashToCompare = user?.passwordHash ?? SECURITY_CONFIG.DUMMY_PASSWORD_HASH;
  const isValid = await bcrypt.compare(password, hashToCompare);

  if (!user || user.deletedAt || !isValid) {
    throw new AuthError(AUTH_ERROR_CODES.INVALID_CREDENTIALS);
  }

  if (!isDemoMode() && !user.emailVerifiedAt) {
    throw new AuthError(AUTH_ERROR_CODES.INVALID_CREDENTIALS);
  }

  const { accessSession } = await createUserSessions(user.id);

  return buildAuthResult(
    {
      id: user.id,
      email: user.email,
      emailVerifiedAt: user.emailVerifiedAt,
      createdAt: user.createdAt,
    },
    mapSession(accessSession),
  );
}

/* ======================
   PASSWORD RESET
====================== */

export async function requestPasswordReset(
  email: string,
): Promise<void | { demoResetPasswordUrl: string }> {
  const user = await prisma.user.findUnique({
    where: { email },
    select: { id: true, email: true, deletedAt: true },
  });

  if (!user || user.deletedAt) {
    return;
  }

  const rawToken = generateToken();
  const tokenHash = tokenToHash(rawToken);

  await prisma.passwordResetToken.create({
    data: {
      userId: user.id,
      tokenHash,
      expiresAt: new Date(Date.now() + TOKEN_TTL.PASSWORD_RESET_MS),
    },
  });

  if (isDemoMode()) {
    return {
      demoResetPasswordUrl: buildLocalePageUrl(`/reset-password?token=${rawToken}`),
    };
  }

  const resetUrl = buildLocalePageUrl(`/reset-password?token=${rawToken}`);

  try {
    const provider = getEmailProvider();

    await provider.send({
      to: user.email,
      subject: 'Reset your password',
      html: `<a href="${resetUrl}">Reset password</a>`,
    });
  } catch {
    console.error('[forgot] send failed:');
  }
}

export async function resetPassword(token: string, newPassword: string): Promise<void> {
  const tokenHash = tokenToHash(token);
  const now = new Date();

  const passwordHash = await bcrypt.hash(newPassword, PASSWORD_SALT_ROUNDS);

  await prisma.$transaction(async (tx) => {
    const updateResult = await tx.passwordResetToken.updateMany({
      where: {
        tokenHash,
        usedAt: null,
        expiresAt: { gt: now },
      },
      data: {
        usedAt: now,
      },
    });

    if (updateResult.count !== 1) {
      throw new AuthError(AUTH_ERROR_CODES.INVALID_RESET_TOKEN);
    }

    const tokenRecord = await tx.passwordResetToken.findUnique({
      where: { tokenHash },
      select: { userId: true },
    });

    if (!tokenRecord) {
      throw new AuthError(AUTH_ERROR_CODES.INVALID_RESET_TOKEN);
    }

    await tx.user.update({
      where: { id: tokenRecord.userId },
      data: { passwordHash },
    });

    await tx.session.updateMany({
      where: { userId: tokenRecord.userId, revokedAt: null },
      data: { revokedAt: now },
    });
  });
}
/* ======================
   RESEND VERIFICATION
====================== */

export async function resendVerification(email: string): Promise<{ success: true }> {
  const user = await prisma.user.findUnique({
    where: { email },
    select: { id: true, deletedAt: true, emailVerifiedAt: true },
  });

  if (!user || user.deletedAt || user.emailVerifiedAt) {
    return { success: true };
  }

  const rawToken = generateToken();
  const tokenHash = tokenToHash(rawToken);

  await prisma.emailVerificationToken.create({
    data: {
      userId: user.id,
      tokenHash,
      expiresAt: new Date(Date.now() + TOKEN_TTL.EMAIL_VERIFICATION_MS),
    },
  });

  if (!isDemoMode()) {
    const verifyUrl = buildLocalePageUrl(`/verify-email?token=${rawToken}`);
    const provider = getEmailProvider();

    await provider.send({
      to: email,
      subject: 'Verify your email',
      html: `<a href="${verifyUrl}">Verify email</a>`,
    });
  }

  return { success: true };
}

/* ======================
   VERIFY EMAIL
====================== */

export async function verifyEmail(token: string): Promise<{ success: true }> {
  const tokenHash = tokenToHash(token);
  const now = new Date();

  await prisma.$transaction(async (tx) => {
    const tokenRecord = await tx.emailVerificationToken.findUnique({
      where: { tokenHash },
      select: {
        id: true,
        userId: true,
        usedAt: true,
        expiresAt: true,
      },
    });

    if (!tokenRecord) {
      throw new AuthError(AUTH_ERROR_CODES.INVALID_VERIFICATION_TOKEN);
    }

    if (tokenRecord.usedAt) {
      throw new AuthError(AUTH_ERROR_CODES.TOKEN_ALREADY_USED);
    }

    if (tokenRecord.expiresAt <= now) {
      throw new AuthError(AUTH_ERROR_CODES.TOKEN_EXPIRED);
    }

    const updateResult = await tx.emailVerificationToken.updateMany({
      where: {
        id: tokenRecord.id,
        usedAt: null,
      },
      data: {
        usedAt: now,
      },
    });

    if (updateResult.count !== 1) {
      throw new AuthError(AUTH_ERROR_CODES.TOKEN_ALREADY_USED);
    }

    await tx.user.update({
      where: { id: tokenRecord.userId },
      data: { emailVerifiedAt: now },
    });
  });

  return { success: true };
}

/* ======================
   SESSION
====================== */

export async function logoutSession(sessionId: string): Promise<void> {
  await revokeSession(sessionId);
}

function mapSession(session: { id: string; userId: string; expiresAt: Date }): AuthSession {
  return {
    sessionId: session.id,
    userId: session.userId,
    expiresAt: session.expiresAt,
  };
}

function buildAuthResult(
  user: {
    id: string;
    email: string;
    emailVerifiedAt: Date | null;
    createdAt: Date;
  },
  session: AuthSession,
): AuthResult {
  const authUser: AuthUser = {
    id: user.id,
    email: user.email,
    emailVerifiedAt: user.emailVerifiedAt,
    createdAt: user.createdAt,
  };

  return { user: authUser, session };
}
