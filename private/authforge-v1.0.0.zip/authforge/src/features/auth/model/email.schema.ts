import { z } from 'zod';
import type { Dictionary } from '@/shared/i18n/getDictionary';

/**
 * Localized validation messages for email schema.
 * Provided by presentation layer (i18n).
 */
export type EmailSchemaMessages = Readonly<{
  required: string;
  invalid: string;
  ascii: string;
}>;

/**
 * Core factory for email validation schema.
 *
 * Enforces:
 * - trimming and normalization
 * - ASCII-only constraint (security / compatibility)
 * - RFC email format validation
 */
export function makeEmailSchema(messages: EmailSchemaMessages) {
  return z
    .string()
    .trim()
    .toLowerCase()
    .nonempty(messages.required)
    .regex(/^[\x00-\x7F]+$/, messages.ascii)
    .email(messages.invalid);
}

/**
 * Auth-specific convenience wrapper.
 *
 * Prevents duplication across login / register / forgot flows.
 */
export function makeEmailWithErrors(errors: Dictionary['auth']['errors']) {
  return makeEmailSchema({
    required: errors.emailRequired,
    invalid: errors.emailInvalid,
    ascii: errors.emailAscii,
  });
}
