import type { EmailProvider, EmailMessage } from '../email.types';

export class DemoEmailProvider implements EmailProvider {
  async send(message: EmailMessage): Promise<void> {
    console.log('[AUTH DEMO EMAIL]');
    console.log('To:', message.to);
    console.log('Subject:', message.subject);

    if (message.html) {
      console.log('Email content:');
      console.log(message.html);
    }
  }
}
