import { Resend } from 'resend';
import type { EmailProvider, EmailMessage } from '../email.types';
import { env } from '@/shared/config/env';

export class ResendEmailProvider implements EmailProvider {
  private client: Resend;

  constructor() {
    if (!env.RESEND_API_KEY) {
      throw new Error('RESEND_API_KEY is not configured');
    }

    this.client = new Resend(env.RESEND_API_KEY);
  }

  async send(message: EmailMessage): Promise<void> {
    if (!env.EMAIL_FROM) {
      throw new Error('EMAIL_FROM is not configured');
    }

    const response = await this.client.emails.send({
      from: env.EMAIL_FROM,
      to: message.to,
      subject: message.subject,
      html: message.html,
    });

    if (response.error) {
      throw new Error(response.error.message);
    }
  }
}
