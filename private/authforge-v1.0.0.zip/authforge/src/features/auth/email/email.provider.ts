import type { EmailProvider } from './email.types';
import { DemoEmailProvider } from './providers/demo.provider';
import { ResendEmailProvider } from './providers/resend.provider';
import { isDemoMode } from '@/shared/config/demo';
import { env } from '@/shared/config/env';

export function getEmailProvider(): EmailProvider {
  if (!isDemoMode() && env.RESEND_API_KEY) {
    return new ResendEmailProvider();
  }

  return new DemoEmailProvider();
}
