import { apiFetch } from '@/shared/api/apiFetch';

import type { LoginFormValues } from '../model/login.schema';
import type { RegisterFormValues } from '../model/register.schema';

export async function login(values: LoginFormValues): Promise<void> {
  await apiFetch<void>('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify(values),
  });
}

export async function logout(): Promise<void> {
  await apiFetch<void>('/api/auth/logout', {
    method: 'POST',
  });
}

export async function register(
  input: RegisterFormValues,
): Promise<{ demoVerificationUrl?: string } | void> {
  try {
    return await apiFetch<{ demoVerificationUrl?: string }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(input),
    });
  } catch (err) {
    if (err instanceof Error) {
      throw err;
    }

    throw new Error('UNKNOWN_ERROR');
  }
}

export async function requestPasswordReset(
  email: string,
): Promise<{ message: string; demoResetPasswordUrl?: string }> {
  return apiFetch<{ message: string; demoResetPasswordUrl?: string }>('/api/auth/forgot-password', {
    method: 'POST',
    body: JSON.stringify({ email }),
  });
}

export async function resetPassword(
  token: string,
  newPassword: string,
): Promise<{ message: string; emailVerified?: boolean }> {
  return apiFetch<{ message: string; emailVerified?: boolean }>(
    `/api/auth/reset-password?token=${encodeURIComponent(token)}`,
    {
      method: 'POST',
      body: JSON.stringify({ newPassword }),
    },
  );
}
