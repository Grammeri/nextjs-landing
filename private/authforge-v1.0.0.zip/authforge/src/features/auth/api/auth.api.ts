import { apiFetch } from '@/shared/api/apiFetch';

import type { LoginFormValues } from '../model/login.schema';
import type { RegisterFormValues } from '../model/register.schema';

type RegisterResponse = {
  demoVerificationUrl?: string;
};

type RequestPasswordResetResponse = {
  demoResetPasswordUrl?: string;
};

export async function login(values: LoginFormValues): Promise<void> {
  await apiFetch<void>('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify(values),
  });
}

export async function logout(): Promise<void> {
  await apiFetch<void>('/api/auth/logout', {
    method: 'POST',
  });
}

export async function register(input: RegisterFormValues): Promise<RegisterResponse> {
  return apiFetch<RegisterResponse>('/api/auth/register', {
    method: 'POST',
    body: JSON.stringify(input),
  });
}

export async function requestPasswordReset(email: string): Promise<RequestPasswordResetResponse> {
  return apiFetch<RequestPasswordResetResponse>('/api/auth/forgot-password', {
    method: 'POST',
    body: JSON.stringify({ email }),
  });
}

export async function resetPassword(token: string, newPassword: string): Promise<void> {
  await apiFetch<void>(`/api/auth/reset-password?token=${encodeURIComponent(token)}`, {
    method: 'POST',
    body: JSON.stringify({ newPassword }),
  });
}
