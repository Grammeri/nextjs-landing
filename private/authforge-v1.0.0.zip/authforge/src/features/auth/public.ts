// Public client-facing API surface for the auth feature.
// Safe for use in client components and UI layers only.

// ==============================
// UI
// ==============================

export { LoginForm } from './ui/LoginForm/LoginForm';
export { RegisterForm } from './ui/RegisterForm/RegisterForm';
export { ForgotPasswordForm } from './ui/ForgotPasswordForm/ForgotPasswordForm';
export { ResetPasswordForm } from './ui/ResetPasswordForm/ResetPasswordForm';

// ==============================
// Client API
// ==============================

export {
  login,
  logout,
  register,
  requestPasswordReset as requestPasswordResetClient,
  resetPassword as resetPasswordClient,
} from './api/auth.api';

// ==============================
// Actions (if needed externally)
// ==============================

export { logout as logoutAction } from './actions/logout';
