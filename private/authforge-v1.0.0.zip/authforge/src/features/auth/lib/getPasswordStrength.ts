type PasswordStrength = {
  score: 1 | 2 | 3;
  label: 'Weak' | 'Medium' | 'Strong';
};

export function getPasswordStrength(password: string): PasswordStrength {
  // Если есть пробел — сразу Weak (соответствует validation)
  if (/\s/.test(password)) {
    return { score: 1, label: 'Weak' };
  }

  let score = 0;

  if (password.length >= 12) score++;
  if (/[A-Z]/.test(password)) score++;
  if (/[a-z]/.test(password)) score++;
  if (/[0-9]/.test(password)) score++;

  if (score <= 1) return { score: 1, label: 'Weak' };
  if (score <= 3) return { score: 2, label: 'Medium' };

  return { score: 3, label: 'Strong' };
}
