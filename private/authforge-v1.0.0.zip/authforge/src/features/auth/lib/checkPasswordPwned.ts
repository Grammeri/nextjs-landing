import crypto from 'node:crypto';

const HIBP_API = 'https://api.pwnedpasswords.com/range/';
const HIBP_TIMEOUT_MS = 3000;

export async function isPasswordPwned(password: string): Promise<boolean> {
  if (process.env.NODE_ENV === 'development') {
    return false;
  }

  try {
    const sha1 = crypto.createHash('sha1').update(password).digest('hex').toUpperCase();

    const prefix = sha1.slice(0, 5);
    const suffix = sha1.slice(5);

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), HIBP_TIMEOUT_MS);

    const response = await fetch(`${HIBP_API}${prefix}`, {
      headers: { 'Add-Padding': 'true' },
      signal: controller.signal,
    });

    clearTimeout(timeout);

    if (!response.ok) {
      return false;
    }

    const text = await response.text();

    return text.split('\n').some((line) => {
      const [hashSuffix] = line.split(':');
      return hashSuffix === suffix;
    });
  } catch {
    return false;
  }
}
