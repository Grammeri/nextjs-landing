import type { AuthErrorCode } from '../model/auth.errors';
import type { Dictionary } from '@/shared/i18n/getDictionary';

type ErrorsDict = Dictionary['auth']['errors'];

const BACKEND_ERROR_MAP: Partial<Record<AuthErrorCode, keyof ErrorsDict>> = {
  EMAIL_ALREADY_EXISTS: 'emailAlreadyExists',
  INVALID_CREDENTIALS: 'invalidCredentials',
  PASSWORD_PWNED: 'passwordPwned',
  TOO_MANY_REQUESTS: 'tooManyAttempts',
  UNKNOWN_ERROR: 'generic',
  VALIDATION_ERROR: 'generic',
  INVALID_JSON_PAYLOAD: 'generic',
  INVALID_RESET_TOKEN: 'generic',
  INVALID_VERIFICATION_TOKEN: 'generic',
  EMAIL_ALREADY_VERIFIED: 'generic',
  EMAIL_NOT_VERIFIED: 'emailNotVerified',
  TOKEN_ALREADY_USED: 'generic',
  TOKEN_EXPIRED: 'generic',
};

export function mapBackendError(code: string, errorsDict: ErrorsDict): string {
  const mappedKey = BACKEND_ERROR_MAP[code as AuthErrorCode];
  return mappedKey ? errorsDict[mappedKey] : errorsDict.generic;
}
