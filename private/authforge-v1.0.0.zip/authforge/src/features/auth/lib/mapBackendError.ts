import type { Dictionary } from '@/shared/i18n/getDictionary';

type ErrorsDict = Dictionary['auth']['errors'];

const BACKEND_ERROR_MAP: Record<string, keyof ErrorsDict> = {
  EMAIL_ALREADY_EXISTS: 'emailAlreadyExists',
  INVALID_CREDENTIALS: 'invalidCredentials',
  PASSWORD_PWNED: 'passwordPwned',
};

export function mapBackendError(code: string, errorsDict: ErrorsDict): string {
  const mappedKey = BACKEND_ERROR_MAP[code];
  return mappedKey ? errorsDict[mappedKey] : errorsDict.generic;
}
