// Server-only public API surface for the auth feature.
// Intended for route handlers and server components.
// Never import this file in client components.

// ==============================
// Domain services
// ==============================

export {
  registerUser,
  loginUser,
  logoutSession,
  requestPasswordReset,
  resetPassword,
  resendVerification,
  verifyEmail,
} from './model/auth.service';

// ==============================
// Sessions
// ==============================

export { validateSession, revokeSession, revokeAllUserSessions } from './model/auth.session';

// ==============================
// Schemas (server usage)
// ==============================

export { makeEmailWithErrors } from './model/email.schema';
export { makeForgotPasswordSchema } from './model/forgot-password.schema';
export { makeLoginSchema } from './model/login.schema';
export { makeRegisterSchema } from './model/register.schema';
export { makeResetPasswordServerSchema } from './model/reset-password.server.schema';

// ==============================
// Security helpers
// ==============================

export { isPasswordPwned } from './lib/checkPasswordPwned';

// ==============================
// Error contracts
// ==============================

export { AUTH_ERROR_CODES, AuthError, type AuthErrorCode } from './model/auth.errors';
