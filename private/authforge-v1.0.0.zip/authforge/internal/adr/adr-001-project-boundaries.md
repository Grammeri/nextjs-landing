# ADR-001: AuthForge — Project Boundary

This document defines the explicit architectural and security boundaries of AuthForge.
Its purpose is to prevent uncontrolled feature expansion and architectural drift.

AuthForge is a source-code authentication foundation.
It is not intended to become a framework, platform, or SaaS.

---

## Purpose

This ADR limits the evolution of the project and ensures:

- Architectural stability
- Security baseline consistency
- Predictable scope
- Controlled public surface
- Sustainable maintenance

Any feature that violates this document requires an explicit architectural review.

## Scope Definition

AuthForge provides:

- Email and password authentication
- Session management
- Password reset and verification flows
- Runtime validation
- Email provider abstraction
- Demo mode
- Infrastructure replaceability

AuthForge intentionally does not provide:

- OAuth providers / social login
- Multi-tenant management
- Role-based authorization framework
- Enterprise SSO
- Payment integration
- User profile system
- Admin dashboard
- Hosted infrastructure

## Security Baseline Commitment

AuthForge guarantees:

- Zod validation on all input
- bcrypt password hashing
- HttpOnly session cookies
- `secure` cookie flag in production
- `sameSite=lax`
- Session expiration enforcement
- Optional breached password detection
- Graceful degradation of external dependencies

AuthForge will not:

- Store plain-text passwords
- Handle secrets in client components
- Move validation logic to UI
- Leak backend implementation details to the client

Security baseline may be strengthened.
It must never be weakened.

## Architectural Boundary Rules

Permanent constraints:

- No Prisma usage outside domain layer
- No business logic inside route handlers
- No secret access in client components
- No wildcard exports of internal modules
- No deep imports across feature boundaries
- No coupling UI to backend-specific constants
- No uncontrolled public API expansion

Violations require ADR revision.

## Complexity Control Policy

Allowed growth:

- Internal hardening
- Security improvements
- Refactors for clarity
- Documentation refinement
- Infrastructure abstraction improvements

Forbidden growth:

- Feature creep
- Framework-level abstractions
- Plugin systems
- Configuration explosion
- Optional modes that alter architecture
- Backward-incompatible public API without a major version change

Complexity must scale linearly.
It must never scale exponentially.

## Public Surface Discipline

Public API surface must remain minimal.

All exports from features must be intentional.
Barrel files must be curated.
Internal helpers must remain internal.

Any new export requires reviewing:

- Necessity
- Stability
- Long-term maintenance cost

## i18n Limitation Policy

AuthForge ships with a single default locale.

Additional locales are extension points, not built-in features.
Core authentication logic must remain language-agnostic.

No architectural complexity may be introduced to support i18n.

## Email System Limitation

Email infrastructure is external by design.

AuthForge provides abstraction.
It does not provide deliverability guarantees.

No internal mail queue system will be added.
No internal SMTP server support will be added.

## Evolution Governance

Before adding a feature, evaluate:

- Does this strengthen the auth foundation?
- Does this increase security?
- Does this simplify architecture?
- Does this preserve a minimal public surface?
- Does this keep the product focused?

If any answer is “no”, the feature does not belong in AuthForge.

## Decision Stability

This document is stable.

Revisions require:

- Explicit rationale
- Consequence analysis
- Architectural impact explanation

AuthForge evolves intentionally.
It does not drift.
