# ADR-009: Authentication Schema Stability Policy

This document defines the stability policy of the authentication database schema used by AuthForge.

Its purpose is to prevent uncontrolled schema evolution and ensure long-term stability
for applications that integrate AuthForge.

AuthForge is a source-code authentication foundation.
Database schema stability is a core part of its architectural contract.

---

## Status

Accepted

## Context

AuthForge persists authentication state in a PostgreSQL database using Prisma ORM.

The authentication schema is responsible for:

- user identity storage
- session lifecycle management
- password reset tokens
- email verification tokens
- external account linkage

Authentication systems must maintain extremely stable persistence models.
Frequent schema changes introduce migration complexity and increase integration risk.

AuthForge prioritizes:

- predictable schema behavior
- safe integration into existing databases
- minimal migration churn
- long-term operational stability

The schema must therefore remain intentionally conservative.

## Decision

The authentication schema defined in `packages/db/prisma/schema.prisma`
is considered **structurally stable** starting from AuthForge v1.0.0.

The schema establishes the following guarantees:

- authentication tables are isolated using the `auth_` prefix
- database columns follow PostgreSQL `snake_case` naming
- Prisma model fields use developer-friendly camelCase mapping
- session lifecycle supports expiration and revocation
- token-based flows use hashed token storage
- soft deletion is supported for user entities

Structural changes to the schema will not be introduced
without a major version release.

Minor releases may introduce:

- additional indexes
- non-breaking constraints
- performance improvements

but must not alter existing data contracts.

## Rationale

Authentication persistence must be stable for several reasons:

- production databases accumulate long-lived authentication data
- schema churn increases migration risk
- authentication systems must remain predictable under load
- integrators may extend the schema with additional application data

A stable schema baseline allows AuthForge to function as a
drop-in authentication foundation.

By isolating authentication tables using the `auth_` namespace,
AuthForge avoids conflicts with application domain tables
and can safely operate inside an existing database.

The camelCase → snake_case mapping strategy provides:

- idiomatic Prisma developer experience
- native PostgreSQL schema conventions
- compatibility with external database tooling

This design balances developer ergonomics with database best practices.

## Consequences

Positive:

- stable authentication persistence model
- predictable database migrations
- safe integration into existing projects
- clear separation between auth data and application data
- reduced long-term maintenance risk

Trade-offs:

- schema evolution becomes more conservative
- new features may require careful compatibility evaluation

These trade-offs are acceptable to guarantee stability.

## Schema Evolution Policy

Future schema changes must satisfy the following conditions:

- must not break existing authentication flows
- must remain compatible with existing user records
- must not introduce database coupling to application domain data
- must not expand the public data contract unnecessarily

Any structural schema change requires:

- architectural review
- migration safety validation
- documentation update
- major version consideration

Authentication persistence stability is a foundational property of AuthForge.

## Stability Commitment

The authentication schema:

- may receive performance hardening
- may receive additional indexes
- may receive non-breaking improvements

It must not introduce disruptive structural changes
without explicit versioning and architectural review.

AuthForge evolves intentionally.

Authentication persistence must remain stable.
