# ADR-006 — Authentication Error Disclosure Policy

This document defines the immutable authentication error disclosure policy used by AuthForge.

It applies to route and domain-level error behavior to preserve security-safe response semantics.

---

## Status

Accepted

## Scope

Applies to all authentication-related API routes and domain services in AuthForge.

## Context

Authentication systems must enforce strict error disclosure boundaries to prevent:

- user enumeration
- token probing
- credential stuffing feedback loops
- internal system exposure
- environment-based behavior drift

AuthForge is a production-ready authentication foundation.
It must ship with a single secure default behavior that is safe for production without configuration toggles.

Error responses must:

- be predictable
- be security-safe
- be infrastructure-agnostic
- not leak sensitive state
- not vary between demo and production modes

## Decision

AuthForge enforces a single immutable authentication error disclosure policy.

There is:

- no debug mode
- no relaxed development behavior
- no environment-based message variation

All authentication errors follow deterministic rules defined below.

## 1. Login Policy

### Response

- HTTP 401
- Generic error message:
  `"Invalid credentials"`

### Never disclosed

- whether the email exists
- whether the password is incorrect
- whether the account is verified
- whether the account is locked
- whether rate limiting was triggered internally

### Rationale

Login responses must not allow user enumeration or credential probing.

## 2. Forgot Password Policy

### Response

Always returns:

- HTTP 200
- Generic success message:

> "If an account with that email exists, a password reset link has been sent."

### Never disclosed

- whether the account exists
- whether email is verified
- whether reset token was created

### Rationale

Forgot password endpoints are common enumeration targets.
Account existence must never be confirmed.

## 3. Register Policy

Registration may return structured, non-sensitive business errors.

### Allowed error types

- ACCOUNT_ALREADY_EXISTS
- VALIDATION_ERROR
- PASSWORD_PWNED
- TOO_MANY_REQUESTS

### Not allowed

- exposing internal database constraints
- exposing hashing failures
- exposing infrastructure failures
- exposing email provider errors

### Rationale

Registration errors do not reveal authentication state and are considered non-sensitive business feedback.

## 4. Email Verification Policy

### Response Behavior

Verification routes:

- must not reveal token validity state
- must not disclose whether token is expired or already used
- must not confirm account existence

All outcomes redirect to login.

### Rationale

Verification tokens are security-sensitive artifacts.
Disclosure of token validity enables probing attacks.

## 5. Reset Password Policy

### Response

- HTTP 200 on success
- HTTP 400/401 only for structurally invalid requests
- HTTP 429 for rate limiting

### Never disclosed

- whether token exists
- whether token expired
- whether token already used

### Rationale

Reset tokens must not become an oracle for account discovery.

## 6. Rate Limiting Policy

When request limits are exceeded:

- HTTP 429
- code: `TOO_MANY_REQUESTS`

Rate limiting is considered infrastructure feedback and does not disclose authentication state.

## 7. System Error Policy

Unexpected internal failures return:

- HTTP 500
- Generic message: `"Internal error"`

Never expose:

- stack traces
- database error details
- provider error messages
- environment variables
- implementation details

## 8. Mode Consistency (Demo vs Production)

Demo mode:

- may stub external side effects
- must not alter authentication logic
- must not alter error disclosure behavior

Production mode:

- identical error disclosure rules

Security policy must remain invariant across modes.

## Invariants

The following must always hold:

- API routes contain no business logic.
- Domain layer determines error type.
- API layer maps domain errors to HTTP responses.
- UI layer maps HTTP status to dictionary-based messages.
- No sensitive state leaks across boundaries.

## Rationale

This policy ensures:

- secure-by-default behavior
- zero configuration security posture
- predictable integration surface
- protection against enumeration attacks
- architectural clarity

It eliminates conditional logic based on environment flags.

Security must not depend on configuration discipline.

## Consequences

### Positive

- Strong production safety baseline
- Deterministic API behavior
- Reduced attack surface
- Clean separation of domain and transport layers

### Trade-offs

- Less granular debugging via API responses
- Developers must inspect server logs for internal errors
- Stricter baseline compared to development-oriented templates
