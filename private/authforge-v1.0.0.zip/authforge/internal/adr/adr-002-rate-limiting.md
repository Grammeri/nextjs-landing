# ADR-002: In-Memory Rate Limiting Strategy

This document defines the baseline anti-abuse rate limiting approach used by AuthForge.

It is intended to preserve architectural boundaries while providing predictable protection for authentication routes.

---

## Status

Accepted

## Context

Authentication endpoints are high-risk entry points for automated abuse.

Common threats include:

- Brute-force login attempts
- Automated account registration
- Password reset flooding

AuthForge is a source-code authentication foundation intended for single-instance deployment by default.

The rate limiting solution must:

- Avoid database schema changes
- Avoid external infrastructure dependencies (e.g., Redis)
- Avoid coupling with the domain layer
- Preserve clean architectural boundaries
- Remain easily replaceable

AuthForge prioritizes architectural clarity over distributed scalability.

## Decision

AuthForge implements a fixed-window, in-memory rate limiting strategy.

### Implementation Characteristics

- Storage: in-memory `Map`
- Key format: `ip + email` (when email is available)
- Limit: 5 attempts
- Time window: 15 minutes
- Enforcement layer: route layer only
- No persistence
- No distributed coordination
- No domain-layer awareness

### Implementation Location

Implementation resides in route-level request handling and shared security helpers.

### Applied To

The rate limiter is applied to the following routes:

- `POST /api/auth/login`
- `POST /api/auth/register`
- `POST /api/auth/forgot-password`

Other routes are intentionally excluded.

## Boundaries

The rate limiter:

- Does not modify Prisma schema
- Does not interact with the database
- Does not implement account lockout
- Does not persist IP history
- Does not provide analytics
- Does not modify domain services
- Does not introduce infrastructure dependencies

It is strictly an infrastructure-level anti-abuse mechanism.

## Rationale

This approach:

- Preserves architectural simplicity
- Prevents domain-layer pollution
- Avoids operational complexity
- Provides reasonable brute-force resistance
- Keeps the system predictable and transparent
- Allows easy replacement in advanced deployments

AuthForge is not designed as a distributed IAM system.

Clustered or horizontally scaled deployments SHOULD replace this implementation with a shared-store rate limiter (e.g., Redis-based).

## Consequences

### Positive

- Improved baseline security
- Zero additional infrastructure requirements
- No database impact
- Clear separation of concerns
- High replaceability
- Minimal complexity footprint

### Limitations

- Not cluster-safe
- State resets on server restart
- Not suitable for enterprise-grade IAM scenarios
- Does not provide analytics or abuse monitoring

## Governance

This ADR defines the baseline rate limiting strategy.

Strengthening the implementation (e.g., distributed store, adaptive throttling) is allowed.

Weakening the security baseline is not allowed.

Any architectural change must preserve:

- Route-layer enforcement
- Domain isolation
- Replaceability
- Minimal infrastructure assumptions
