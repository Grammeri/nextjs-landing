# ADR-008: Prisma Version Baseline Policy

This document defines the ORM baseline policy of AuthForge.

Its purpose is to ensure predictable behavior of the database layer
and prevent instability caused by major dependency shifts.

AuthForge is a production-ready authentication foundation.
Stability of persistence behavior is a non-negotiable requirement.

---

## Status

Accepted

## Context

AuthForge relies on Prisma ORM for:

- relational data integrity
- session persistence
- token lifecycle management
- migration-based schema history

Major ORM upgrades may introduce architectural shifts,
runtime configuration changes, or new infrastructure requirements.

AuthForge prioritizes:

- traditional Node.js server environments
- PostgreSQL deployments
- predictable SSR behavior
- minimal configuration surface

A stable ORM baseline is required to preserve these guarantees.

## Decision

AuthForge v1.0.0 is validated against **Prisma 6.x**.

Prisma 6.x is adopted as the stable baseline for:

- Node.js server runtime
- PostgreSQL-backed deployments
- session-based authentication architecture

Major Prisma upgrades will not be adopted automatically.
They require explicit architectural review.

## Rationale

Prisma 6.x provides:

- mature Node.js runtime support
- stable query engine behavior
- no adapter configuration requirements
- predictable integration with Next.js server rendering

AuthForge avoids:

- experimental runtime modes
- mandatory adapter configuration
- infrastructure coupling introduced by major ORM shifts
- configuration complexity visible to template users

The authentication foundation must remain simple and predictable.

## Consequences

Positive:

- Stable SSR behavior
- Minimal ORM configuration
- Reduced cognitive load for users
- Clear dependency baseline
- Simplified upgrade governance

Trade-offs:

- Major Prisma features may not be adopted immediately
- Upgrade path to future ORM versions requires review

These trade-offs are acceptable in favor of architectural stability.

## Upgrade Governance Policy

Future Prisma major upgrades require:

- architectural impact evaluation
- SSR compatibility validation
- migration compatibility testing
- documentation update
- dedicated release cycle

Major ORM upgrades must never be introduced silently.

## Stability Commitment

The ORM baseline:

- may be hardened
- may receive minor/patch upgrades
- must not introduce breaking architectural shifts without a major release

AuthForge evolves intentionally.
Persistence stability is foundational.
