# ADR-004: Optional Dictionary-Based Internationalization

This document defines the optional dictionary-based i18n policy for AuthForge.

It describes how localization support is enabled without coupling authentication domain logic to translation infrastructure.

---

## Status

Accepted

## Context

AuthForge is a source-code authentication foundation.

Some consuming applications require multilingual UI.
Others ship in a single language and prefer minimal surface area.

We need an approach that:

- keeps domain logic independent from UI translations
- supports optional locale routing
- allows consumers to remove i18n without rewriting the auth domain

## Decision

AuthForge uses an optional dictionary-based i18n strategy:

- UI routes may include a locale segment: `/[locale]/...`
- Edge middleware handles locale detection and redirection for page routes only.
- Dictionaries are loaded server-side via `getDictionary()` and passed to UI components via props.
- Authentication domain logic and API routes never import dictionaries and remain locale-agnostic.

AuthForge ships with a single default dictionary (`en`) as the baseline language.
Additional locales are an extension point.

## Consequences

### Positive

- Clean separation: domain logic does not depend on translation tooling.
- Consumers can add new languages by adding dictionaries.
- Consumers can remove i18n with a predictable set of changes.
- Locale routing applies only to UI routes, not API routes.

### Negative

- Passing dictionaries through UI props adds verbosity.
- Locale routing introduces additional route structure for consumers who do not need it.

## Removal / Simplification Playbook (for consumers)

A consuming application may disable i18n by:

1. Removing the locale middleware call (`handleI18n`) or deleting `src/middleware.ts`.
2. Flattening `/src/app/[locale]/...` routes into `/src/app/...`.
3. Replacing dictionary props with plain strings or a single static text object.

Domain logic does not require any changes.
