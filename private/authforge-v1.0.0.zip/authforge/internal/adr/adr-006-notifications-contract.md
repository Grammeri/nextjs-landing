# ADR-005: Notification Contract (i18n-agnostic)

This document defines the notification contract used by AuthForge UI flows.

It ensures notification behavior remains replaceable and independent from translation tooling.

---

## Status

Accepted

## Context

AuthForge uses toast notifications for UX feedback (e.g. login success, password reset, email verified).

Direct imports of a toast library inside features create coupling and make replacement harder.
Notifications must also remain independent from i18n: translated strings are a UI concern.

## Decision

AuthForge defines a shared notification contract:

- Features must not import toast libraries directly.
- Features use `notify.success(message)` / `notify.error(message)` from `shared`.
- The notification layer accepts plain strings and is i18n-agnostic.
- Dictionaries are used by UI to produce message strings, not by the notification system itself.

## Consequences

- Swapping toast libraries becomes a single-file change.
- Features remain clean and portable.
- i18n remains optional and does not affect notification infrastructure.
