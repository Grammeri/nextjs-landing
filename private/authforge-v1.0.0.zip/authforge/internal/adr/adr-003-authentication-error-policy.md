# ADR — Form Validation Error Reset Policy

This document defines the validation behavior standard for all AuthForge forms.

It formalizes how field-level and server-level errors must behave in the UI layer.

---

## Context

AuthForge forms use:

- React Hook Form
- Zod schemas
- Server-side validation via API routes

Field validation errors originate from schema validation.

Server-level errors originate from API responses.

Without a consistent reset policy, validation errors may remain visible after the user
starts correcting input, creating a perception of a non-responsive form.

User experience must remain predictable and responsive.

## Decision

All field-level validation errors MUST be cleared immediately after the user modifies
at least one character in the corresponding input field.

This applies to:

- email
- password
- confirm password
- any future form fields

Server-level errors MUST be cleared on any form value change.

Errors MUST NOT persist while the user is actively correcting input.

Validation logic MUST remain in schema.

Error reset behavior MUST remain in UI layer.

## Rationale

This decision enforces:

- responsive form behavior
- immediate feedback loop
- reduced cognitive friction
- alignment with modern SaaS UX standards

The system must communicate:

- error appears when validation fails
- error disappears when correction begins

The user must never feel "blocked" by a stale validation message.

## Implementation Rules

Field-level errors:

- MUST use `form.clearErrors(fieldName)` inside `onChange`
- MUST NOT depend solely on blur
- MUST NOT require submit to disappear

Server-level errors:

- MUST be cleared via `form.watch` subscription
- MUST reset error state on any value change

Cross-field validation:

- MUST remain inside schema using `superRefine`
- MUST NOT move business logic into UI
- UI MAY trigger revalidation when needed

## Non-Goals

This policy does not:

- relax validation rules
- remove schema enforcement
- modify backend validation
- allow invalid submission

Validation strictness remains unchanged.

Only visibility timing is affected.

## Consequences

Positive:

- Consistent UX across all forms
- Enterprise-grade interaction behavior
- Clear separation of concerns

Neutral:

- Slight increase in UI wiring complexity

Negative:

- Developers must follow this policy explicitly
- Deviation creates inconsistent UX

## Status

Accepted.

Applies to:

- LoginForm
- RegisterForm
- ForgotPasswordForm
- ResetPasswordForm
- All future AuthForge forms
