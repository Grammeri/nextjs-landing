# Baseline Migration Strategy for Template Release

This document defines the official policy for squashing Prisma migrations before releasing AuthForge as a production-ready template.

It applies to release preparation and version packaging workflows.

---

## Context

During active development, multiple Prisma migrations are created to reflect schema evolution.

Example development history:

- init
- token hashing refactor
- email verification simplification
- redundant index removal

This history is valid for development but is not suitable for distribution in a commercial template product.

AuthForge is a source-code template, not a living SaaS. Buyers must receive a clean, deterministic starting state.

## Decision

Before any public release (e.g. v1.0.0), all development migrations MUST be squashed into a single baseline migration.

The released template MUST contain exactly one migration folder representing the finalized schema.

Migration history remains preserved in Git history and internal documentation, not in the distributed template.

## Rationale

The baseline strategy ensures:

- deterministic database initialization
- elimination of internal refactor history
- professional release presentation
- reduced cognitive load for buyers
- production-grade distribution structure

Template consumers should see only the final schema, not the internal evolution process.

## Release Procedure

### Step 1 — Ensure schema is final

Verify that:

- Prisma schema is finalized
- No further structural changes are expected
- All tests pass

### Step 2 — Remove existing migrations

Delete the migrations directory:

```bash
rm -rf packages/db/prisma/migrations
```

The file migration_lock.toml MUST remain.

### Step 3 — Reset development database

Destroy local development database to ensure clean state:

```bash
docker compose down -v
```

Then restart database:

```bash
pnpm db:up
```

### Step 4 — Create baseline migration

Generate a single new migration:

```bash
pnpm prisma migrate dev --name init
```

This creates:

```text
migrations/
2026xxxx_init/
```

Only one migration must exist.

### Step 5 — Verify clean deployment

Test production-style migration:

```bash
pnpm prisma migrate deploy
```

Confirm that:

- Database initializes correctly
- All tables exist
- Application boots successfully

## Verification Checklist

Before packaging release:

- Only one migration folder exists
- No legacy migration folders remain
- Database initializes from zero state
- No warnings during migrate deploy
- Template runs from clean clone

## Distribution Rule

The distributed ZIP package MUST contain:

- finalized Prisma schema
- one baseline migration
- no development migration history
- no local database files
- no Docker volumes

The buyer generates their own database using their own environment.

## Non-Goals

This strategy does NOT:

- remove Git history
- rewrite development commits
- modify schema design
- affect runtime behavior

It only affects distribution structure.

## Documentation Impact

This ADR applies to:

- release documentation
- internal release checklist
- template packaging workflow

It does not need to be exposed to end users unless database internals are explicitly documented.

## Final Principle

Development history is internal.

Released state is final.

AuthForge must ship as a finished system, not a work in progress.
