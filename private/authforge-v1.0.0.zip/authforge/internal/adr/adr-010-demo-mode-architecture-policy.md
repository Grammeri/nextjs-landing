# ADR-010: Demo Mode Architecture Policy

This document defines the architectural policy governing the Demo Mode
implementation used by AuthForge.

Its purpose is to provide a frictionless evaluation experience while
preserving the production architecture and integrity of the authentication
system.

AuthForge is a source-code authentication foundation.
Demo capabilities must therefore remain strictly controlled and
architecturally isolated.

---

## Status

Accepted

## Context

AuthForge is designed to be evaluated quickly by developers
after cloning the repository.

However, a fully operational authentication system normally requires:

- a configured PostgreSQL database
- an operational email delivery provider
- environment configuration
- database migrations

These operational requirements create friction during initial
evaluation and experimentation.

Developers exploring the system should be able to:

- run the project locally without configuring external services
- explore authentication flows
- inspect UI behavior
- understand system architecture

without being blocked by infrastructure setup.

At the same time, introducing evaluation shortcuts must not compromise
the integrity of the authentication domain or pollute the production
architecture with evaluation-specific logic.

Demo capabilities must therefore be implemented as a controlled
runtime configuration.

## Decision

AuthForge provides a **Demo Mode** that allows the system to operate
without external dependencies while preserving the same architectural
boundaries used in production.

Demo Mode is controlled through environment configuration
and must never require modification of application source code.

When Demo Mode is enabled:

- external side effects are replaced with controlled local stubs
- authentication domain logic remains unchanged
- API routes maintain identical request handling behavior
- UI components remain identical to production behavior
- the database schema and persistence model remain unchanged

Demo Mode must not alter the internal authentication rules
or bypass domain validation logic.

The following components may use demo implementations:

- email delivery providers
- token delivery mechanisms
- optional demonstration authentication flows

All demo functionality must remain isolated within dedicated
demo modules and must not be mixed into production domain logic.

Demo functionality must be explicitly gated by environment configuration.

## Architectural Isolation

Demo functionality must remain isolated in dedicated modules
located in the shared infrastructure layer.

Example structure:

```
src/shared/demo/
```

Demo modules may provide:

- demo authentication flows
- demo email providers
- stub implementations for external integrations

Production code must never depend directly on demo modules.

Instead, runtime configuration determines which provider
implementation is used.

This preserves architectural purity and prevents
demo logic from leaking into production behavior.

## Rationale

Demo Mode serves three primary purposes:

1. **Evaluation Experience**

Developers can explore AuthForge immediately without configuring
external infrastructure.

2. **Architecture Demonstration**

Demo Mode allows the system architecture to remain visible and
inspectable without hiding core components behind external services.

3. **Operational Safety**

Because Demo Mode only replaces external side effects,
the authentication domain remains fully intact and production-ready.

This approach avoids introducing artificial shortcuts
or weakening the authentication model.

## Consequences

Positive:

- immediate developer onboarding
- frictionless local evaluation
- preserved architectural integrity
- no pollution of production domain logic
- clear separation between demo infrastructure and production infrastructure

Trade-offs:

- additional runtime configuration complexity
- small increase in infrastructure abstraction layers

These trade-offs are acceptable in order to maintain both
evaluation usability and architectural purity.

## Operational Policy

Demo Mode must only be used for:

- local development
- internal demonstrations
- evaluation of the authentication system

Demo Mode must not be enabled in publicly accessible
production deployments.

Production deployments must explicitly disable Demo Mode
and configure real infrastructure providers.

## Implementation Constraints

Demo Mode must satisfy the following architectural constraints:

- demo logic must remain isolated in dedicated modules
- demo logic must not modify authentication domain rules
- demo logic must not bypass validation or session policies
- demo logic must not alter database schema behavior
- demo logic must be fully disabled through environment configuration

Authentication architecture must remain identical
between Demo Mode and Production Mode.

Demo Mode must not introduce synthetic or static tokens.

All verification and reset tokens must be generated,
hashed, validated, and expired using the same mechanisms
as production environments.

## Long-Term Policy

Demo Mode is considered a permanent evaluation feature of AuthForge.

Future development must ensure that:

- demo capabilities remain architecturally isolated
- demo functionality does not expand beyond evaluation purposes
- production behavior remains unaffected by demo infrastructure

AuthForge prioritizes architectural clarity and operational stability.

Evaluation capabilities must support this goal without
introducing hidden complexity.

## Stability Commitment

Demo Mode may evolve to improve developer onboarding and
evaluation experience.

However, demo functionality must never:

- alter the authentication domain model
- weaken authentication security boundaries
- introduce production runtime dependencies
- compromise architectural layering

AuthForge maintains strict separation between
production infrastructure and evaluation infrastructure.

Demo Mode exists to simplify exploration,
not to modify the authentication system itself.
