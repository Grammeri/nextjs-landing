import { defineConfig, globalIgnores } from 'eslint/config';
import nextVitals from 'eslint-config-next/core-web-vitals';
import nextTs from 'eslint-config-next/typescript';

export default defineConfig([
  ...nextVitals,
  ...nextTs,

  globalIgnores(['.next/**', 'out/**', 'build/**', 'next-env.d.ts']),

  {
    rules: {
      'eol-last': 'off',
    },
  },

  {
    files: ['src/**/*.{ts,tsx}'],

    rules: {
      'no-restricted-imports': [
        'error',
        {
          paths: [
            {
              name: '@/features/auth',
              message:
                'Do not import from "@/features/auth". Use "@/features/auth/public" (client/UI) or "@/features/auth/server" (server-only).',
            },
          ],

          patterns: [
            {
              group: [
                '@/features/*/ui/*',
                '@/features/*/model/*',
                '@/features/*/api/*',
                '@/features/*/actions/*',
              ],
              message:
                'Do not import deep modules from features. Use "@/features/<feature>/public" or "@/features/<feature>/server" instead.',
            },
          ],
        },
      ],
    },
  },
]);
