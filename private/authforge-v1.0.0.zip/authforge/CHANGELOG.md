# AuthForge Changelog

## v1.0.0

Initial public release of AuthForge.

Features included in this release:

- Email and password authentication
- Email verification flow
- Password reset flow
- Session management with HttpOnly cookies
- Demo mode for local development
- Prisma ORM with PostgreSQL
- Feature-Sliced Design architecture
- Zod-based validation
- Rate limiting protection
- Secure authentication token handling

This release represents the first stable version of AuthForge.
