AuthForge v1.0.0
Release date: 2026-03
