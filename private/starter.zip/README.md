# Frontend Test Assignment

A small web application built with **Next.js** and **TypeScript** as part of a frontend developer test assignment.

---

# Requirements

Before running the project make sure you have installed:

- Node.js **20+**
- pnpm (recommended) or npm

---

# Getting Started

Install dependencies:

```bash
pnpm install
```

or

```bash
npm install
```

Start the development server:

```bash
pnpm dev
```

or

```bash
npm run dev
```

The application will be available at:

```
http://localhost:3000
```

---

# Production Build

Build the project:

```bash
pnpm build
```

Run the production server:

```bash
pnpm start
```

---

# Available Scripts

| Command       | Description                                      |
| ------------- | ------------------------------------------------ |
| `pnpm dev`    | Start development server                         |
| `pnpm build`  | Build the project for production                 |
| `pnpm start`  | Start production server                          |
| `pnpm lint`   | Run ESLint                                       |
| `pnpm format` | Format code using Prettier                       |
| `pnpm check`  | Run type checking, linting and formatting checks |

All commands are also available via `npm run`.

---

# Tech Stack

- **Next.js** — React framework
- **React** — UI library
- **TypeScript** — typed JavaScript
- **ESLint** — code linting
- **Prettier** — code formatting

---

# Project Structure

```
src/
  app/          Application pages and layouts
public/         Static assets
```

Important configuration files:

```
next.config.ts
tsconfig.json
eslint.config.mjs
.prettierrc
```

---

# Notes

This project was implemented as part of a frontend developer test assignment.
